from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sqlalchemy import inspect, select  # noqa: E402

from app.database import Department, Institution, SessionLocal, engine  # noqa: E402


IDENTIFIER_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{2,79}$")
DEPARTMENT_CODE_RE = re.compile(r"^[A-Z][A-Z0-9_-]{1,59}$")


def parse_department(value: str) -> tuple[str, str]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("departments must use CODE=Name format")
    code, name = value.split("=", 1)
    code, name = code.strip().upper(), name.strip()
    if not DEPARTMENT_CODE_RE.fullmatch(code):
        raise argparse.ArgumentTypeError(f"invalid department code: {code!r}")
    if len(name) < 3 or len(name) > 180:
        raise argparse.ArgumentTypeError("department name must be 3–180 characters")
    return code, name


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Provision an institution and its initial departments in the MWANGAZA database."
    )
    parser.add_argument("--institution-id", required=True, help="Stable tenant ID to place in trusted Supabase app_metadata")
    parser.add_argument("--name", required=True, help="Institution display name")
    parser.add_argument(
        "--department", action="append", type=parse_department, default=[], metavar="CODE=NAME",
        help="Initial department; may be repeated, for example --department TECH='Technology & Innovation'",
    )
    args = parser.parse_args()

    institution_id = args.institution_id.strip().lower()
    institution_name = args.name.strip()
    if not IDENTIFIER_RE.fullmatch(institution_id):
        parser.error("--institution-id must be 3–80 lowercase letters, digits, underscores or hyphens")
    if len(institution_name) < 3 or len(institution_name) > 180:
        parser.error("--name must be 3–180 characters")
    codes = [code for code, _ in args.department]
    if len(codes) != len(set(codes)):
        parser.error("department codes must be unique in this command")

    if not inspect(engine).has_table("institutions"):
        print("Database schema is not migrated. Run `python -m alembic upgrade head` before provisioning.", file=sys.stderr)
        return 2

    db = SessionLocal()
    try:
        institution = db.get(Institution, institution_id)
        institution_created = institution is None
        if institution is None:
            institution = Institution(id=institution_id, name=institution_name, is_demo=0)
            db.add(institution)
            db.flush()
        elif institution.name != institution_name:
            parser.error("institution ID already exists with a different name; refusing to overwrite")

        department_results = []
        for code, name in args.department:
            existing = db.scalar(
                select(Department).where(
                    Department.institution_id == institution_id,
                    Department.code == code,
                )
            )
            if existing:
                if existing.name != name:
                    parser.error(f"department {code} already exists with a different name; refusing to overwrite")
                department_results.append({"id": existing.id, "code": existing.code, "name": existing.name, "created": False})
                continue
            item = Department(
                id=str(uuid4()), institution_id=institution_id, code=code, name=name,
            )
            db.add(item)
            db.flush()
            department_results.append({"id": item.id, "code": item.code, "name": item.name, "created": True})

        db.commit()
        print(json.dumps({
            "institution": {"id": institution.id, "name": institution.name, "created": institution_created},
            "departments": department_results,
            "next_step": (
                "Provision the initial administrator in Supabase Auth with trusted app_metadata "
                f"institution_id='{institution_id}' and role='admin'. Use a department_id from the list for department-scoped users."
            ),
        }, indent=2, default=str))
        return 0
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
