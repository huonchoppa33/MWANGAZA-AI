# MWANGAZA Core 0.2

**Institutional Evidence-to-Action Intelligence System — integrated prototype**

> MWANGAZA is an independent engineering prototype. It is not an official Swahilipot system and is not connected to Swahilipot's internal databases, accounts, APIs or records. Bundled programme figures are synthetic and must never be reported as actual institutional results.

## What is implemented in 0.2

### Backend and data foundations

- FastAPI service with OpenAPI documentation.
- SQLAlchemy data model for institutions, departments, programmes, cohorts, data sources, staged imports, attendance events, indicators, interventions, knowledge documents, document chunks and audit records.
- SQLite development mode and PostgreSQL support through `psycopg`.
- Alembic migrations, including an upgrade path for the bundled 0.1 SQLite schema.
- Supabase JWT verification using asymmetric JWKS keys or an explicitly configured legacy HS256 secret.
- Institution scoping on registry, import, indicator, document, attendance and intervention queries.
- Role-based API permissions (`admin`, `executive`, `programme_manager`, `analyst`, `staff`, `viewer`) with institution and department-scoped visibility for programmes, cohorts, attendance, imports, interventions and documents.
- Department-scoped roles receive only their assigned department records; users without a trusted department claim receive no department records. Institution-wide roles are restricted to `admin`, `executive` and `analyst`.
- A trusted tenant-provisioning CLI for creating an institution and its first departments before Supabase users are assigned.
- An administrator/executive-only API route for adding departments after tenant provisioning.
- Demo authentication is allowed only when `APP_ENV=development`; demo routes are disabled outside development and the application refuses to start in production with demo authentication.
- Backend settings are loaded from a project `.env` file when present; existing process environment variables take precedence.

### Data intake and governance

- Register institution-specific data sources.
- Register programmes and cohorts.
- Stage an attendance CSV, validate rows and preview accepted/rejected records.
- Require an authorised `admin` or `executive` to approve staged imports.
- Persist approved attendance events without overwriting source files.
- Prevent duplicate file staging and skip event IDs already stored in the same institution.
- Version indicator definitions instead of silently overwriting their meaning.
- Store source provenance and audit metadata.

CSV imports require these columns:

```text
event_id,cohort_id,session_date,enrolled_count,attendance_count
```

Every `cohort_id` must already exist as an active cohort in the authenticated institution. Attendance counts must be valid and cannot exceed the enrolled count or the registered cohort capacity.

### Institutional intelligence

- Institution-specific programme, cohort and attendance summary.
- Explainable low-attendance and declining-trend signals.
- Experimental linear attendance projection with limitations.
- Intervention register with proposed → active → evaluated states.
- Cohort-specific enrolment denominator checks during evaluation.
- Audit records for imports, source registrations, indicator versions, intervention actions and knowledge queries.

### Knowledge AI

- Upload PDF, DOCX, TXT and Markdown documents.
- Extract text and split it into searchable chunks.
- TF-IDF retrieval scoped by institution and department visibility.
- Source references with document names and chunk IDs.
- Extractive evidence mode works without an API key.
- Optional OpenAI Responses API adapter, disabled by default. Retrieved document chunks are sent to the external provider only when `OPENAI_API_KEY` is configured and `ALLOW_EXTERNAL_AI=true`.

The knowledge assistant is a retrieval prototype, not a fine-tuned institutional foundation model. Relevance scores are not proof that a document is complete, current or authoritative.

### Frontend

Next.js dashboard with four sections:

1. Institutional overview.
2. Data intake and source registration.
3. Knowledge document upload and research assistant.
4. Intervention register and follow-up evaluation.

When Supabase frontend variables are configured, the dashboard displays a Supabase email/password sign-in form. Without them, it uses local development demo mode.

## 1. Requirements

- Python 3.11 or newer.
- Node.js 20 or newer and npm 10 or newer for the Next.js frontend.
- PostgreSQL for production; SQLite is used for local development.

## 2. Start the backend on Windows

Open PowerShell in the project root:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
python -m alembic upgrade head
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

The bundled `scripts/run_windows.ps1` performs the installation, migration and API start steps.

Useful URLs:

- API documentation: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/api/v1/health
- Local identity: http://127.0.0.1:8000/api/v1/identity
- Dashboard summary: http://127.0.0.1:8000/api/v1/dashboard/summary

## 3. Start the frontend

Open a second terminal:

```powershell
cd frontend
Copy-Item .env.example .env.local
npm install
npm run dev
```

Open http://localhost:3000.

The backend must be running on port 8000. Set `NEXT_PUBLIC_API_BASE_URL` in `frontend/.env.local` if it runs elsewhere.

## 4. Local demo mode

Defaults in `.env.example` are intended only for local development:

```dotenv
APP_ENV=development
AUTH_MODE=demo
DATABASE_URL=sqlite:///./mwangaza.db
```

The local development identity is a synthetic administrator for `demo-institution`. Its built-in programme and cohort data are synthetic. The dashboard labels these metrics. Do not use demo mode on a public deployment.

## 5. Provision a new institution

Run database migrations first, then create the institution and its initial departments using the trusted provisioning script. Execute this from the project root with the intended database configured in `.env` or `DATABASE_URL`: 

```powershell
python -m alembic upgrade head
python scripts/provision_institution.py --institution-id coastal-hub --name "Coastal Innovation Hub" --department "TECH=Technology & Innovation" --department "ARTS=Creative Arts" --department "ENTERPRISE=Entrepreneurship"
```

The command is idempotent for matching institution and department records and refuses to overwrite conflicting names. It prints the department IDs. Configure Supabase users with trusted `app_metadata.institution_id`, `app_metadata.role`, and, for department-scoped roles, the matching `app_metadata.department_id`. The script provisions database records only; it does not create Supabase accounts or assign user roles. After provisioning, an `admin` or `executive` can add departments through `POST /api/v1/departments`.

## 6. Supabase authentication and PostgreSQL

For an institutional environment, configure the backend with a managed PostgreSQL connection and Supabase Auth:

```dotenv
APP_ENV=production
AUTH_MODE=supabase
DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST:5432/DATABASE
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_JWKS_URL=https://YOUR_PROJECT.supabase.co/auth/v1/.well-known/jwks.json
CORS_ORIGINS=https://YOUR-FRONTEND-DOMAIN
ALLOW_EXTERNAL_AI=false
```

Use Supabase's asymmetric signing keys and JWKS verification where available. The backend checks the issuer, audience, expiry and signature. It reads trusted custom claims from `app_metadata`:

```json
{
  "institution_id": "institution-identifier",
  "role": "admin",
  "department_id": "optional-department-identifier"
}
```

The `role` and `institution_id` claims must be set by a trusted server-side process or Supabase Auth Hook. Do not put trusted role claims in user-editable `user_metadata`.

Set these frontend variables in `frontend/.env.local` or the deployment platform:

```dotenv
NEXT_PUBLIC_API_BASE_URL=https://YOUR-API-DOMAIN
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

Never expose a Supabase service-role key or database password to the browser. Configure role mappings and institution membership before allowing staff to sign in.

## 7. Migrations

Apply migrations before starting the API:

```powershell
python -m alembic upgrade head
```

Check the current migration:

```powershell
python -m alembic current
```

The migration sequence creates the 0.2 institutional schema, adds tenant scope to an existing 0.1 intervention table, and adds programme/cohort registries. Back up a real database before applying any migration.

## 8. Testing

From the project root:

```powershell
python -m pytest -q
```

The suite includes API and engine checks, source registration, CSV staging and approval, idempotent event imports, indicator versioning, knowledge document retrieval, department visibility, tenant-separated dashboard metrics and institutional provisioning coverage.

## 9. Optional external AI

External AI is disabled by default:

```dotenv
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
ALLOW_EXTERNAL_AI=false
```

Only after the institution approves the provider, data-processing terms, retention settings and document classes may the deployment set `ALLOW_EXTERNAL_AI=true`. When enabled, retrieved document chunks—not the entire database—are sent to the OpenAI Responses API. Keep participant-identifying, confidential and sensitive information out of the external AI path unless expressly authorised and legally reviewed.

## Current limitations and production gates

- No Swahilipot internal data, accounts or integrations are connected.
- The bundled metrics are synthetic; imported records are only as reliable as their source and definitions.
- The document retriever uses TF-IDF, not semantic embeddings or a fine-tuned model.
- The optional LLM response mode requires explicit external-provider approval and configuration.
- No automated participant eligibility, vulnerability, wellbeing or risk decisions are implemented.
- Cohort attendance forecasting is experimental and requires representative historical data, backtesting and baseline comparison.
- The current intervention evaluation is descriptive. It does not establish causal impact.
- Department-level record and document visibility is enforced by the API, but database-level RLS remains a recommended defence-in-depth control.
- Full document lifecycle, deletion, retention automation and export controls still need implementation.
- The frontend uses Next.js 15.5.29 (Maintenance LTS) and Supabase JS 2.119.0. It has passed source syntax and a limited TypeScript check in this environment, but a full Next.js build must be run after `npm install` in a network-enabled environment.
- Production still requires a formal data inventory, institutional approval, lawful basis, DPIA where required, role provisioning, backup/recovery testing, secret management, monitoring, security assessment and a controlled pilot.
- Frontend dependencies must be installed in a network-enabled development environment before running a Next.js production build.

See `docs/CORE_0.2_SPECIFICATION.md`, `docs/ARCHITECTURE.md`, `docs/DATA_MODEL.md` and `docs/SECURITY_AND_DEPLOYMENT.md`.
