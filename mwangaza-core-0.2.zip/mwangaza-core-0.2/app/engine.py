from __future__ import annotations

from datetime import date
from typing import Any

import numpy as np

from app.demo_data import COHORTS, PROGRAMMES, RESOURCES, ATTENDANCE_SESSIONS
from app.schemas import EvidenceItem, Insight


class IntelligenceEngine:
    """Explainable first-pass analytics; not a trained or production-validated AI model."""

    def __init__(self, dataset: dict | None = None):
        self.demo_only = dataset is None or bool(dataset.get("demo_only", False))
        self.dataset = dataset or {
            "programmes": PROGRAMMES,
            "cohorts": COHORTS,
            "attendance_sessions": ATTENDANCE_SESSIONS,
            "resources": RESOURCES,
            "demo_only": True,
        }

    def cohort_sessions(self, cohort_id: str) -> list[dict[str, Any]]:
        rows = [r for r in self.dataset["attendance_sessions"] if r["cohort_id"] == cohort_id]
        return sorted(rows, key=lambda row: row["session_date"])

    def attendance_rate(self, rows: list[dict[str, Any]]) -> float:
        if not rows:
            return 0.0
        total_attended = sum(int(row["attendance_count"]) for row in rows)
        total_enrolled = sum(int(row["enrolled_count"]) for row in rows)
        return total_attended / total_enrolled if total_enrolled else 0.0

    def overview(self) -> dict[str, Any]:
        cohorts = []
        for cohort in self.dataset["cohorts"]:
            rows = self.cohort_sessions(cohort["cohort_id"])
            latest = rows[-1] if rows else None
            cohorts.append({
                **cohort,
                "session_count": len(rows),
                "overall_attendance_rate": round(self.attendance_rate(rows), 4),
                "latest_attendance_rate": round(latest["attendance_count"] / latest["enrolled_count"], 4) if latest else None,
            })
        all_rows = self.dataset["attendance_sessions"]
        return {
            "demo_only": self.demo_only,
            "dataset_notice": (
                "Synthetic demonstration data only; not Swahilipot operational data."
                if self.demo_only else "Tenant-scoped operational records imported into this workspace; completeness and source validity still require verification."
            ),
            "programme_count": len(self.dataset["programmes"]),
            "cohort_count": len(self.dataset["cohorts"]),
            "attendance_session_count": len(all_rows),
            "overall_attendance_rate": round(self.attendance_rate(all_rows), 4),
            "cohorts": cohorts,
            "resource_summary": [
                {**r, "utilization_rate": round(r["allocated"] / r["capacity"], 4) if r["capacity"] else None}
                for r in self.dataset["resources"]
            ],
        }

    def insights(self) -> list[Insight]:
        results: list[Insight] = []
        for cohort in self.dataset["cohorts"]:
            rows = self.cohort_sessions(cohort["cohort_id"])
            if len(rows) < 4:
                continue
            latest = rows[-3:]
            latest_rate = self.attendance_rate(latest)
            session_rates = np.array([r["attendance_count"] / r["enrolled_count"] for r in rows], dtype=float)
            slope = float(np.polyfit(np.arange(len(session_rates)), session_rates, 1)[0])
            programme = next((p for p in self.dataset["programmes"] if p["programme_id"] == cohort["programme_id"]), None)

            if latest_rate < 0.75:
                results.append(Insight(
                    demo_only=self.demo_only,
                    insight_id=f"ATTENDANCE-LOW-{cohort['cohort_id']}",
                    category="attendance",
                    severity="high" if latest_rate < 0.65 else "watch",
                    title=f"Low recent attendance in {cohort['name']}",
                    finding=f"Attendance across the latest three sessions is {latest_rate:.1%} of enrolled places.",
                    recommendation="Ask the programme team to review scheduling, access, session relevance and equipment constraints before selecting an intervention.",
                    confidence="high",
                    evidence=[EvidenceItem(source_id=r["event_id"], description=f"{r['attendance_count']} of {r['enrolled_count']} enrolled attended on {r['session_date']}") for r in latest],
                    limitations=["Attendance alone does not establish why participants were absent."] + (["All records in this prototype are synthetic."] if self.demo_only else ["Findings depend on the completeness and quality of imported attendance records."]),
                ))
            if slope < -0.015:
                results.append(Insight(
                    demo_only=self.demo_only,
                    insight_id=f"ATTENDANCE-DECLINE-{cohort['cohort_id']}",
                    category="attendance",
                    severity="high" if slope < -0.03 else "watch",
                    title=f"Declining attendance trend in {cohort['name']}",
                    finding=f"The fitted linear trend is {slope * 100:.2f} percentage points per session over {len(rows)} sessions.",
                    recommendation="Investigate the timing of the decline and compare it with session schedules, connectivity, facilitator changes and participant feedback.",
                    confidence="medium",
                    evidence=[EvidenceItem(source_id=r["event_id"], description=f"Session attendance rate: {r['attendance_count'] / r['enrolled_count']:.1%}") for r in rows],
                    limitations=["A linear trend is descriptive and may not continue into future sessions.", "The trend does not establish causation."] + (["All records in this prototype are synthetic."] if self.demo_only else ["Imported event records may be incomplete or affected by reporting changes."]),
                ))

        for resource in self.dataset["resources"]:
            if resource["capacity"] <= 0:
                continue
            utilization = resource["allocated"] / resource["capacity"]
            if utilization >= 0.85:
                results.append(Insight(
                    demo_only=self.demo_only,
                    insight_id=f"CAPACITY-{resource['resource_id']}",
                    category="capacity",
                    severity="high" if utilization >= 0.95 else "watch",
                    title=f"High utilisation: {resource['resource_type']}",
                    finding=f"{resource['allocated']} of {resource['capacity']} available slots are allocated ({utilization:.1%}).",
                    recommendation="Review the allocation schedule and confirm whether demand overlaps before adding capacity or moving sessions.",
                    confidence="high",
                    evidence=[EvidenceItem(source_id=resource["resource_id"], description=f"Allocated {resource['allocated']} of capacity {resource['capacity']}")],
                    limitations=["Allocation does not necessarily mean simultaneous use.", "The resource records are synthetic."],
                ))
        return results

    def forecast_attendance(self, cohort_id: str, horizon: int = 4) -> dict[str, Any]:
        rows = self.cohort_sessions(cohort_id)
        if len(rows) < 4:
            return {
                "cohort_id": cohort_id,
                "method": "linear trend baseline (experimental)",
                "historical_sessions_used": len(rows),
                "forecast": [],
                "limitations": ["At least four valid historical sessions are required."],
                "status": "insufficient_data",
            }
        rates = np.array([r["attendance_count"] / r["enrolled_count"] for r in rows], dtype=float)
        x = np.arange(len(rates), dtype=float)
        slope, intercept = np.polyfit(x, rates, 1)
        forecast = []
        for step in range(1, horizon + 1):
            value = float(np.clip(intercept + slope * (len(rates) - 1 + step), 0.0, 1.0))
            forecast.append({"period": step, "predicted_attendance_rate": round(value, 4)})
        return {
            "cohort_id": cohort_id,
            "method": "ordinary least-squares linear trend baseline; not a validated predictive model",
            "historical_sessions_used": len(rows),
            "forecast": forecast,
            "limitations": [
                "Experimental projection using synthetic data." if self.demo_only else "Experimental projection using imported institution-scoped attendance records.",
                "No seasonality, holidays, participant-level behaviour or external factors are modelled.",
                "Forecast values are not causal estimates and must not drive participant-level decisions.",
                "Validate against simple historical baselines before any real deployment.",
            ],
            "status": "experimental",
        }

    def validate_attendance_records(self, records: list[dict[str, Any]]) -> dict[str, Any]:
        seen: set[str] = set()
        accepted: list[dict[str, Any]] = []
        errors: list[dict[str, str | int]] = []
        duplicates: list[str] = []
        for index, row in enumerate(records):
            event_id = str(row.get("event_id", ""))
            if not event_id:
                errors.append({"index": index, "field": "event_id", "message": "event_id is required"})
                continue
            if event_id in seen:
                duplicates.append(event_id)
                errors.append({"index": index, "field": "event_id", "message": "Duplicate event_id"})
                continue
            seen.add(event_id)
            try:
                enrolled = int(row.get("enrolled_count", 0))
                attended = int(row.get("attendance_count", -1))
                if enrolled <= 0:
                    raise ValueError("enrolled_count must be greater than zero")
                if attended < 0 or attended > enrolled:
                    raise ValueError("attendance_count must be between zero and enrolled_count")
                if not row.get("cohort_id") or not row.get("session_date") or not row.get("source_id"):
                    raise ValueError("cohort_id, session_date and source_id are required")
                date.fromisoformat(str(row["session_date"]))
                accepted.append(row)
            except (ValueError, TypeError) as exc:
                errors.append({"index": index, "field": "record", "message": str(exc)})
        return {
            "accepted_count": len(accepted),
            "rejected_count": len(records) - len(accepted),
            "duplicate_event_ids": sorted(set(duplicates)),
            "accepted_records": accepted,
            "errors": errors,
        }


def intervention_baseline(engine: IntelligenceEngine, cohort_id: str, session_count: int = 3) -> tuple[float, int]:
    rows = engine.cohort_sessions(cohort_id)
    if len(rows) < session_count:
        raise ValueError(f"Cohort needs at least {session_count} sessions to create a baseline")
    selected = rows[-session_count:]
    return engine.attendance_rate(selected), len(selected)
