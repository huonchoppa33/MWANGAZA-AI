from __future__ import annotations

import io
import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Iterable

from docx import Document as DocxDocument
from pypdf import PdfReader
from sqlalchemy import select
from sqlalchemy.orm import Session
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.auth import Principal
from app.config import settings
from app.database import DocumentChunk, KnowledgeDocument


@dataclass
class ExtractedPage:
    page_number: int | None
    text: str


def extract_document(filename: str, content: bytes) -> list[ExtractedPage]:
    suffix = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if suffix in {"txt", "md", "csv"}:
        text = content.decode("utf-8-sig", errors="replace")
        return [ExtractedPage(None, text)]
    if suffix == "pdf":
        reader = PdfReader(io.BytesIO(content))
        return [ExtractedPage(i + 1, page.extract_text() or "") for i, page in enumerate(reader.pages)]
    if suffix == "docx":
        document = DocxDocument(io.BytesIO(content))
        paragraphs = [p.text for p in document.paragraphs if p.text.strip()]
        return [ExtractedPage(None, "\n".join(paragraphs))]
    raise ValueError("Unsupported file type. Upload PDF, DOCX, TXT or MD files.")


def chunk_pages(pages: Iterable[ExtractedPage], chunk_size: int = 1400, overlap: int = 180) -> list[tuple[int | None, str]]:
    output: list[tuple[int | None, str]] = []
    for page in pages:
        text = re.sub(r"\s+", " ", page.text).strip()
        if not text:
            continue
        start = 0
        while start < len(text):
            end = min(start + chunk_size, len(text))
            segment = text[start:end].strip()
            if segment:
                output.append((page.page_number, segment))
            if end == len(text):
                break
            start = max(end - overlap, start + 1)
    return output


def retrieve_chunks(db: Session, principal: Principal, question: str, top_k: int = 5):
    query = (
        select(DocumentChunk, KnowledgeDocument)
        .join(KnowledgeDocument, KnowledgeDocument.id == DocumentChunk.document_id)
        .where(
            DocumentChunk.institution_id == principal.institution_id,
            KnowledgeDocument.institution_id == principal.institution_id,
            KnowledgeDocument.status == "active",
        )
    )
    if principal.role not in {"admin", "executive"}:
        if principal.department_id:
            query = query.where(
                (KnowledgeDocument.visibility == "institution")
                | (KnowledgeDocument.department_id == principal.department_id)
            )
        else:
            query = query.where(KnowledgeDocument.visibility == "institution")
    rows = list(db.execute(query).all())
    if not rows:
        return []
    texts = [chunk.content for chunk, _doc in rows]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
    try:
        matrix = vectorizer.fit_transform(texts + [question])
        scores = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
    except ValueError:
        return []
    order = scores.argsort()[::-1]
    results = []
    for rank, idx in enumerate(order[:top_k], start=1):
        score = float(scores[idx])
        if score <= 0:
            continue
        chunk, doc = rows[int(idx)]
        results.append({
            "citation": f"S{rank}",
            "document_id": doc.id,
            "file_name": doc.file_name,
            "chunk_index": chunk.chunk_index,
            "page_number": chunk.page_number,
            "snippet": chunk.content[:1100],
            "relevance": round(score, 4),
        })
    return results


def _openai_grounded_answer(question: str, sources: list[dict]) -> str | None:
    if not (settings.openai_api_key and settings.allow_external_ai):
        return None
    evidence = "\n\n".join(
        f"[{s['citation']}] {s['file_name']} (chunk {s['chunk_index']}, page {s.get('page_number')}):\n{s['snippet']}"
        for s in sources
    )
    payload = {
        "model": settings.openai_model,
        "input": [
            {
                "role": "system",
                "content": "You are MWANGAZA's institutional document research assistant. Answer only from the supplied evidence. Cite every material factual claim using [S1] style references. If the evidence does not answer the question, say so. Do not infer personal characteristics, make eligibility decisions, or invent institutional facts. State uncertainty and conflicting evidence.",
            },
            {"role": "user", "content": f"Question: {question}\n\nApproved evidence:\n{evidence}"},
        ],
        "store": False,
    }
    request = urllib.request.Request(
        "https://api.openai.com/v1/responses",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=25) as response:
            body = json.loads(response.read().decode("utf-8"))
        pieces = []
        for output in body.get("output", []):
            for item in output.get("content", []):
                if item.get("type") == "output_text" and item.get("text"):
                    pieces.append(item["text"])
        return "\n".join(pieces).strip() or None
    except (urllib.error.URLError, TimeoutError, ValueError, KeyError):
        return None


def answer_question(question: str, sources: list[dict]) -> tuple[str, str]:
    if not sources:
        return (
            "I could not find relevant evidence in the documents you are permitted to access. "
            "Try a more specific question or upload an approved source document.",
            "extractive",
        )
    grounded = _openai_grounded_answer(question, sources)
    if grounded:
        return grounded, "openai_grounded"
    bullets = []
    for source in sources:
        location = f", page {source['page_number']}" if source.get("page_number") else ""
        bullets.append(f"[{source['citation']}] **{source['file_name']}**{location}: {source['snippet']}")
    answer = (
        "I found relevant passages, but the external language model is not enabled. "
        "The following is an extractive evidence view, not a generated institutional conclusion:\n\n"
        + "\n\n".join(bullets)
    )
    return answer, "extractive"
