from __future__ import annotations

from datetime import date, datetime, timezone
from uuid import uuid4

from sqlalchemy import Date, DateTime, Float, Integer, String, Text, UniqueConstraint, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from app.config import settings

database_url = settings.database_url.replace("postgresql://", "postgresql+psycopg://", 1) if settings.database_url.startswith("postgresql://") else settings.database_url
connect_args = {"check_same_thread": False} if database_url.startswith("sqlite") else {}
engine = create_engine(database_url, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


class Intervention(Base):
    __tablename__ = "interventions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, default="demo-institution", index=True)
    title: Mapped[str] = mapped_column(String(180), nullable=False)
    cohort_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    management_question: Mapped[str] = mapped_column(Text, nullable=False)
    hypothesis: Mapped[str] = mapped_column(Text, nullable=False)
    planned_action: Mapped[str] = mapped_column(Text, nullable=False)
    owner_role: Mapped[str] = mapped_column(String(100), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="proposed")
    baseline_attendance_rate: Mapped[float] = mapped_column(Float, nullable=False)
    baseline_session_count: Mapped[int] = mapped_column(Integer, nullable=False)
    review_date: Mapped[date] = mapped_column(Date, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    implemented_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    follow_up_attendance_rate: Mapped[float | None] = mapped_column(Float, nullable=True)
    change_percentage_points: Mapped[float | None] = mapped_column(Float, nullable=True)
    evaluation_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    evidence_references: Mapped[str | None] = mapped_column(Text, nullable=True)


class Institution(Base):
    __tablename__ = "institutions"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    is_demo: Mapped[bool] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class Programme(Base):
    __tablename__ = "programmes"
    __table_args__ = (UniqueConstraint("institution_id", "code", name="uq_programme_institution_code"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(80), nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    department_id: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class Cohort(Base):
    __tablename__ = "cohorts"
    __table_args__ = (UniqueConstraint("institution_id", "code", name="uq_cohort_institution_code"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    programme_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(80), nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    enrolled_count: Mapped[int] = mapped_column(Integer, nullable=False)
    capacity: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class Department(Base):
    __tablename__ = "departments"
    __table_args__ = (UniqueConstraint("institution_id", "code", name="uq_department_institution_code"),)

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(60), nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)


class DataSource(Base):
    __tablename__ = "data_sources"
    __table_args__ = (UniqueConstraint("institution_id", "name", name="uq_source_institution_name"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    kind: Mapped[str] = mapped_column(String(40), nullable=False, default="file")
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner_role: Mapped[str] = mapped_column(String(100), nullable=False, default="Data Steward")
    enabled: Mapped[bool] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class ImportBatch(Base):
    __tablename__ = "import_batches"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    source_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    file_name: Mapped[str] = mapped_column(String(255), nullable=False)
    file_sha256: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="pending")
    total_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    accepted_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    rejected_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    staged_records_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    errors_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    created_by: Mapped[str] = mapped_column(String(120), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    approved_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class AttendanceEvent(Base):
    __tablename__ = "attendance_events"
    __table_args__ = (UniqueConstraint("institution_id", "event_id", name="uq_attendance_institution_event"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    event_id: Mapped[str] = mapped_column(String(80), nullable=False)
    cohort_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    session_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    enrolled_count: Mapped[int] = mapped_column(Integer, nullable=False)
    attendance_count: Mapped[int] = mapped_column(Integer, nullable=False)
    source_id: Mapped[str] = mapped_column(String(36), nullable=False)
    batch_id: Mapped[str] = mapped_column(String(36), nullable=False)
    provenance_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class IndicatorDefinition(Base):
    __tablename__ = "indicator_definitions"
    __table_args__ = (UniqueConstraint("institution_id", "code", "version", name="uq_indicator_version"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(80), nullable=False)
    name: Mapped[str] = mapped_column(String(180), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    numerator_definition: Mapped[str] = mapped_column(Text, nullable=False)
    denominator_definition: Mapped[str] = mapped_column(Text, nullable=False)
    unit: Mapped[str] = mapped_column(String(40), nullable=False, default="percentage")
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    owner_role: Mapped[str] = mapped_column(String(100), nullable=False)
    active: Mapped[bool] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class KnowledgeDocument(Base):
    __tablename__ = "knowledge_documents"
    __table_args__ = (UniqueConstraint("institution_id", "sha256", name="uq_document_institution_sha"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    department_id: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    file_name: Mapped[str] = mapped_column(String(255), nullable=False)
    mime_type: Mapped[str] = mapped_column(String(120), nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    visibility: Mapped[str] = mapped_column(String(30), nullable=False, default="institution")
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="active")
    chunk_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    uploaded_by: Mapped[str] = mapped_column(String(120), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class DocumentChunk(Base):
    __tablename__ = "document_chunks"
    __table_args__ = (UniqueConstraint("document_id", "chunk_index", name="uq_document_chunk"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    document_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    chunk_index: Mapped[int] = mapped_column(Integer, nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    page_number: Mapped[int | None] = mapped_column(Integer, nullable=True)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    institution_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    actor_id: Mapped[str] = mapped_column(String(120), nullable=False)
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(100), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(120), nullable=False)
    details_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


def seed_demo_tenant(db: Session | None = None) -> None:
    own_session = db is None
    session = db or SessionLocal()
    try:
        if session.get(Institution, "demo-institution") is None:
            session.add(Institution(id="demo-institution", name="Synthetic Coastal Innovation Hub", is_demo=1))
            session.flush()
        departments = [
            ("dept-technology", "TECH", "Technology & Innovation"),
            ("dept-creative", "CREATIVE", "Creative Arts"),
            ("dept-enterprise", "ENTERPRISE", "Entrepreneurship"),
        ]
        for dept_id, code, name in departments:
            if session.get(Department, dept_id) is None:
                session.add(Department(id=dept_id, institution_id="demo-institution", code=code, name=name))
        programmes = [
            ("PRG-TECH", "Technology Foundations", "dept-technology"),
            ("PRG-CREAT", "Creative Enterprise Lab", "dept-creative"),
            ("PRG-ENT", "Entrepreneurship Accelerator", "dept-enterprise"),
        ]
        programme_ids = {}
        for code, name, department_id in programmes:
            existing = session.scalar(select(Programme).where(Programme.institution_id == "demo-institution", Programme.code == code))
            if existing is None:
                existing = Programme(institution_id="demo-institution", code=code, name=name, department_id=department_id, active=1)
                session.add(existing)
                session.flush()
            programme_ids[code] = existing.id
        cohorts = [
            ("COH-TECH-A", "PRG-TECH", "Technology Cohort A", 32, 36),
            ("COH-CREAT-B", "PRG-CREAT", "Creative Cohort B", 24, 30),
            ("COH-ENT-A", "PRG-ENT", "Enterprise Cohort A", 28, 30),
        ]
        for cohort_code, programme_code, name, enrolled_count, capacity in cohorts:
            existing = session.scalar(select(Cohort).where(Cohort.institution_id == "demo-institution", Cohort.code == cohort_code))
            if existing is None:
                session.add(Cohort(institution_id="demo-institution", programme_id=programme_ids[programme_code], code=cohort_code, name=name, enrolled_count=enrolled_count, capacity=capacity, status="active"))
        sources = [
            ("demo-attendance", "Synthetic attendance dataset", "synthetic"),
            ("manual-csv", "Manual CSV upload", "file"),
        ]
        for source_id, name, kind in sources:
            if session.get(DataSource, source_id) is None:
                session.add(DataSource(id=source_id, institution_id="demo-institution", name=name, kind=kind, description="Development-only sample source"))
        session.commit()
    finally:
        if own_session:
            session.close()


def log_audit(db: Session, institution_id: str, actor_id: str, action: str, entity_type: str, entity_id: str, details: dict | None = None) -> None:
    import json
    db.add(AuditLog(
        institution_id=institution_id,
        actor_id=actor_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details_json=json.dumps(details or {}, sort_keys=True),
    ))



def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_intervention(db: Session, **kwargs) -> Intervention:
    item = Intervention(**kwargs)
    db.add(item)
    db.flush()
    return item


def get_intervention(db: Session, intervention_id: str) -> Intervention | None:
    return db.get(Intervention, intervention_id)


def list_interventions(db: Session, institution_id: str = "demo-institution") -> list[Intervention]:
    return list(db.scalars(select(Intervention).where(Intervention.institution_id == institution_id).order_by(Intervention.created_at.desc())).all())
