from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

# Read the project .env before constructing settings. Existing process environment
# variables take precedence over values from the file.
load_dotenv(override=False)


@dataclass(frozen=True)
class Settings:
    app_name: str = "MWANGAZA Core API"
    app_version: str = "0.2.0"
    environment: str = os.getenv("APP_ENV", "development")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./mwangaza.db")
    auth_mode: str = os.getenv("AUTH_MODE", "demo").lower()
    supabase_url: str = os.getenv("SUPABASE_URL", "").rstrip("/")
    supabase_jwks_url: str = os.getenv("SUPABASE_JWKS_URL", "")
    supabase_jwt_secret: str = os.getenv("SUPABASE_JWT_SECRET", "")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    allow_external_ai: bool = os.getenv("ALLOW_EXTERNAL_AI", "false").lower() == "true"
    cors_origins: tuple[str, ...] = tuple(
        origin.strip()
        for origin in os.getenv("CORS_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000").split(",")
        if origin.strip()
    )
    max_upload_bytes: int = int(os.getenv("MAX_UPLOAD_BYTES", str(8 * 1024 * 1024)))


settings = Settings()

if settings.auth_mode not in {"demo", "supabase"}:
    raise RuntimeError("AUTH_MODE must be 'demo' or 'supabase'")
if settings.auth_mode == "supabase" and not settings.supabase_url:
    raise RuntimeError("SUPABASE_URL is required when AUTH_MODE=supabase")
if settings.auth_mode == "supabase" and not (settings.supabase_jwks_url or settings.supabase_jwt_secret):
    raise RuntimeError("Configure SUPABASE_JWKS_URL or SUPABASE_JWT_SECRET when AUTH_MODE=supabase")
if settings.environment == "production" and settings.auth_mode == "demo":
    raise RuntimeError("AUTH_MODE=demo is prohibited when APP_ENV=production")
if settings.environment == "production" and not settings.database_url.startswith(("postgresql://", "postgresql+psycopg://")):
    raise RuntimeError("Production deployments must use PostgreSQL")
