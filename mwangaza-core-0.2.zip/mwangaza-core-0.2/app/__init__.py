"""MWANGAZA institutional intelligence prototype."""
