"""Synthetic demonstration data. No Swahilipot operational records are used."""
from __future__ import annotations

from datetime import date, timedelta

DEMO_ONLY = True

PROGRAMMES = [
    {"programme_id": "PRG-TECH", "name": "Technology Foundations", "department": "Technology & Innovation"},
    {"programme_id": "PRG-CREAT", "name": "Creative Enterprise Lab", "department": "Creative Arts"},
    {"programme_id": "PRG-ENT", "name": "Entrepreneurship Accelerator", "department": "Entrepreneurship"},
]

COHORTS = [
    {"cohort_id": "COH-TECH-A", "programme_id": "PRG-TECH", "name": "Technology Cohort A", "enrolled_count": 32, "capacity": 36},
    {"cohort_id": "COH-CREAT-B", "programme_id": "PRG-CREAT", "name": "Creative Cohort B", "enrolled_count": 24, "capacity": 30},
    {"cohort_id": "COH-ENT-A", "programme_id": "PRG-ENT", "name": "Enterprise Cohort A", "enrolled_count": 28, "capacity": 30},
]

_ATTENDANCE = {
    "COH-TECH-A": [30, 29, 28, 26, 24, 22, 21, 19, 18, 17],
    "COH-CREAT-B": [22, 22, 21, 21, 20, 20, 20, 19, 19, 18],
    "COH-ENT-A": [27, 27, 26, 26, 25, 25, 25, 24, 24, 24],
}

START_DATE = date(2026, 8, 3)
ATTENDANCE_SESSIONS: list[dict] = []
for cohort_id, counts in _ATTENDANCE.items():
    enrolled = next(c["enrolled_count"] for c in COHORTS if c["cohort_id"] == cohort_id)
    for index, count in enumerate(counts):
        ATTENDANCE_SESSIONS.append(
            {
                "event_id": f"EVT-{cohort_id}-{index + 1:02d}",
                "cohort_id": cohort_id,
                "session_date": START_DATE + timedelta(days=index * 7),
                "attendance_count": count,
                "enrolled_count": enrolled,
                "source_id": "SYNTHETIC-DEMO-DATASET-V1",
            }
        )

RESOURCES = [
    {"resource_id": "RES-LAB-01", "resource_type": "computer_lab", "capacity": 24, "allocated": 22, "programme_id": "PRG-TECH"},
    {"resource_id": "RES-STUDIO-01", "resource_type": "creative_studio", "capacity": 20, "allocated": 14, "programme_id": "PRG-CREAT"},
    {"resource_id": "RES-MENTOR-POOL", "resource_type": "mentor_slots", "capacity": 18, "allocated": 17, "programme_id": "PRG-ENT"},
]


def get_demo_dataset() -> dict:
    return {
        "dataset_notice": "SYNTHETIC DEMONSTRATION DATA — NOT SWAHILIPOT RECORDS",
        "institution": {"name": "Synthetic Coastal Innovation Hub", "demo_only": True},
        "programmes": PROGRAMMES,
        "cohorts": COHORTS,
        "attendance_sessions": ATTENDANCE_SESSIONS,
        "resources": RESOURCES,
    }
