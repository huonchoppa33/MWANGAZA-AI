from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Annotated

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.config import settings

bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class Principal:
    user_id: str
    institution_id: str
    role: str
    department_id: str | None = None
    demo_mode: bool = False


@lru_cache(maxsize=1)
def _jwks_client():
    url = settings.supabase_jwks_url or (f"{settings.supabase_url}/auth/v1/.well-known/jwks.json" if settings.supabase_url else "")
    if not url:
        raise RuntimeError("Configure SUPABASE_JWKS_URL or SUPABASE_URL for Supabase authentication")
    return jwt.PyJWKClient(url, cache_keys=True)


def current_principal(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
) -> Principal:
    if settings.auth_mode == "demo":
        if settings.environment != "development":
            raise HTTPException(status_code=503, detail="Demo authentication is only available in development")
        if credentials:
            raise HTTPException(status_code=401, detail="Do not send a bearer token while AUTH_MODE=demo")
        return Principal(
            user_id="local-demo-user",
            institution_id="demo-institution",
            role="admin",
            department_id=None,
            demo_mode=True,
        )

    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Bearer token required")

    token = credentials.credentials
    try:
        header = jwt.get_unverified_header(token)
        algorithm = header.get("alg", "")
        if settings.supabase_jwt_secret:
            if algorithm != "HS256":
                raise HTTPException(status_code=401, detail="Unexpected token signing algorithm")
            claims = jwt.decode(
                token,
                settings.supabase_jwt_secret,
                algorithms=["HS256"],
                audience="authenticated",
                issuer=f"{settings.supabase_url}/auth/v1",
                options={"require": ["exp", "sub"]},
            )
        else:
            if algorithm not in {"ES256", "RS256"}:
                raise HTTPException(status_code=401, detail="Unsupported Supabase token signing algorithm")
            signing_key = _jwks_client().get_signing_key_from_jwt(token).key
            claims = jwt.decode(
                token,
                signing_key,
                algorithms=[algorithm],
                audience="authenticated",
                issuer=f"{settings.supabase_url}/auth/v1",
                options={"require": ["exp", "sub"]},
            )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid or expired access token") from exc

    app_metadata = claims.get("app_metadata") or {}
    institution_id = app_metadata.get("institution_id")
    role = app_metadata.get("role")
    if not institution_id or not role:
        raise HTTPException(
            status_code=403,
            detail="Token is missing trusted app_metadata.institution_id or app_metadata.role claims",
        )
    return Principal(
        user_id=str(claims["sub"]),
        institution_id=str(institution_id),
        role=str(role),
        department_id=app_metadata.get("department_id"),
        demo_mode=False,
    )


def require_roles(*allowed: str):
    def dependency(principal: Annotated[Principal, Depends(current_principal)]) -> Principal:
        if principal.role not in allowed:
            raise HTTPException(status_code=403, detail="Your role is not permitted to perform this action")
        return principal
    return dependency


READ_ROLES = ("admin", "executive", "programme_manager", "analyst", "staff", "viewer")
WRITE_ROLES = ("admin", "executive", "programme_manager", "analyst")
APPROVE_ROLES = ("admin", "executive")
