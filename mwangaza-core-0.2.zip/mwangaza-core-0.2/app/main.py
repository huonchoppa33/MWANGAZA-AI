from __future__ import annotations

import csv
import hashlib
import io
import json
from datetime import datetime, timezone
from typing import Annotated
from uuid import uuid4

from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.auth import APPROVE_ROLES, READ_ROLES, WRITE_ROLES, Principal, current_principal, require_roles
from app.config import settings
from app.database import (
    AttendanceEvent,
    AuditLog,
    Base,
    Cohort,
    DataSource,
    Department,
    DocumentChunk,
    ImportBatch,
    IndicatorDefinition,
    Institution,
    Intervention,
    KnowledgeDocument,
    Programme,
    create_intervention,
    engine as db_engine,
    get_db,
    get_intervention,
    list_interventions,
    log_audit,
    seed_demo_tenant,
)
from app.demo_data import get_demo_dataset
from app.engine import IntelligenceEngine, intervention_baseline
from app.knowledge import answer_question, chunk_pages, extract_document, retrieve_chunks
from app.schemas import (
    AttendanceForecast,
    AttendanceSession,
    DashboardSummary,
    DataSourceCreate,
    DataSourceOut,
    DepartmentCreate,
    DataValidationRequest,
    DataValidationResponse,
    ImportBatchOut,
    IndicatorCreate,
    IndicatorOut,
    InterventionCreate,
    InterventionEvaluationRequest,
    InterventionOut,
    Insight,
    KnowledgeAnswer,
    KnowledgeQuery,
    KnowledgeSource,
    CohortCreate,
    CohortOut,
    ProgrammeCreate,
    ProgrammeOut,
)

if settings.environment == "development":
    Base.metadata.create_all(bind=db_engine)
    seed_demo_tenant()
intelligence = IntelligenceEngine()


FULL_INSTITUTION_SCOPE_ROLES = {"admin", "executive", "analyst"}


def has_full_institution_scope(principal: Principal) -> bool:
    return principal.demo_mode or principal.role in FULL_INSTITUTION_SCOPE_ROLES


def visible_programmes_query(principal: Principal):
    query = select(Programme).where(Programme.institution_id == principal.institution_id, Programme.active == 1)
    if not has_full_institution_scope(principal):
        if not principal.department_id:
            return query.where(Programme.id == "__no_department_scope__")
        query = query.where(Programme.department_id == principal.department_id)
    return query


def visible_cohorts_query(principal: Principal):
    query = (
        select(Cohort)
        .join(Programme, Cohort.programme_id == Programme.id)
        .where(
            Cohort.institution_id == principal.institution_id,
            Cohort.status == "active",
            Programme.institution_id == principal.institution_id,
            Programme.active == 1,
        )
    )
    if not has_full_institution_scope(principal):
        if not principal.department_id:
            return query.where(Programme.id == "__no_department_scope__")
        query = query.where(Programme.department_id == principal.department_id)
    return query


def visible_cohort_codes(principal: Principal, db: Session) -> set[str]:
    return {row.code for row in db.scalars(visible_cohorts_query(principal)).all()}


def batch_in_scope(batch: ImportBatch, principal: Principal, db: Session) -> bool:
    if has_full_institution_scope(principal):
        return True
    if batch.created_by == principal.user_id:
        return True
    allowed = visible_cohort_codes(principal, db)
    try:
        records = json.loads(batch.staged_records_json)
    except (TypeError, json.JSONDecodeError):
        return False
    return bool(records) and all(record.get("cohort_id") in allowed for record in records)


def tenant_intelligence(principal: Principal, db: Session) -> IntelligenceEngine:
    if principal.demo_mode:
        return intelligence
    programmes = db.scalars(visible_programmes_query(principal)).all()
    programme_ids = {programme.id for programme in programmes}
    cohorts = db.scalars(visible_cohorts_query(principal)).all()
    cohort_codes = {cohort.code for cohort in cohorts}
    events_query = select(AttendanceEvent).where(AttendanceEvent.institution_id == principal.institution_id)
    if not has_full_institution_scope(principal):
        if not cohort_codes:
            events_query = events_query.where(AttendanceEvent.id == "__no_department_scope__")
        else:
            events_query = events_query.where(AttendanceEvent.cohort_id.in_(cohort_codes))
    events = db.scalars(events_query).all()
    dataset = {
        "demo_only": False,
        "programmes": [{"programme_id": p.id, "name": p.name, "department_id": p.department_id} for p in programmes],
        "cohorts": [{"cohort_id": c.code, "programme_id": c.programme_id, "name": c.name, "enrolled_count": c.enrolled_count, "capacity": c.capacity} for c in cohorts],
        "attendance_sessions": [{"event_id": e.event_id, "cohort_id": e.cohort_id, "session_date": e.session_date, "enrolled_count": e.enrolled_count, "attendance_count": e.attendance_count, "source_id": e.source_id} for e in events],
        "resources": [],
    }
    return IntelligenceEngine(dataset)


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Institutional intelligence prototype. Bundled programme data are synthetic. "
        "This is an independent prototype, not an official Swahilipot system."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.cors_origins),
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


def _batch_out(item: ImportBatch) -> ImportBatchOut:
    return ImportBatchOut.model_validate(item)


@app.get("/", tags=["system"])
def root():
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "status": "running",
        "data_mode": ("development_synthetic_demo_and_tenant_storage" if settings.environment == "development" else "tenant_scoped_storage"),
        "auth_mode": settings.auth_mode,
        "docs": "/docs",
    }


@app.get("/api/v1/health", tags=["system"])
def health():
    return {"status": "healthy", "version": settings.app_version, "environment": settings.environment}


@app.get("/api/v1/identity", tags=["identity"])
def identity(principal: Annotated[Principal, Depends(current_principal)]):
    return {
        "user_id": principal.user_id,
        "institution_id": principal.institution_id,
        "role": principal.role,
        "department_id": principal.department_id,
        "demo_mode": principal.demo_mode,
        "notice": "Development identity only" if principal.demo_mode else "Authenticated Supabase identity",
    }


def require_development_demo() -> None:
    if settings.environment != "development":
        raise HTTPException(status_code=404, detail="Demo routes are available only in development")


@app.get("/api/v1/demo/dataset", tags=["demo"])
def demo_dataset():
    require_development_demo()
    return get_demo_dataset()


@app.get("/api/v1/demo/overview", tags=["demo"])
def demo_overview():
    require_development_demo()
    return intelligence.overview()


@app.get("/api/v1/dashboard/summary", response_model=DashboardSummary, tags=["dashboard"])
def dashboard_summary(
    principal: Annotated[Principal, Depends(current_principal)],
    db: Session = Depends(get_db),
):
    tenant_engine = tenant_intelligence(principal, db)
    overview = tenant_engine.overview()
    def count(model, *conditions):
        stmt = select(func.count()).select_from(model).where(*conditions)
        return int(db.scalar(stmt) or 0)

    institution = db.get(Institution, principal.institution_id)
    visible_codes = visible_cohort_codes(principal, db)
    attendance_conditions = [AttendanceEvent.institution_id == principal.institution_id]
    intervention_conditions = [Intervention.institution_id == principal.institution_id]
    if not has_full_institution_scope(principal):
        attendance_conditions.append(AttendanceEvent.cohort_id.in_(visible_codes) if visible_codes else AttendanceEvent.id == "__no_department_scope__")
        intervention_conditions.append(Intervention.cohort_id.in_(visible_codes) if visible_codes else Intervention.id == "__no_department_scope__")
    document_query = select(func.count()).select_from(KnowledgeDocument).where(
        KnowledgeDocument.institution_id == principal.institution_id, KnowledgeDocument.status == "active"
    )
    if not has_full_institution_scope(principal):
        if principal.department_id:
            document_query = document_query.where((KnowledgeDocument.visibility == "institution") | (KnowledgeDocument.department_id == principal.department_id))
        else:
            document_query = document_query.where(KnowledgeDocument.visibility == "institution")
    return DashboardSummary(
        institution_name=institution.name if institution else principal.institution_id,
        environment=settings.environment,
        demo_only=principal.demo_mode,
        programme_count=overview["programme_count"],
        cohort_count=overview["cohort_count"],
        attendance_session_count=overview["attendance_session_count"],
        overall_attendance_rate=overview["overall_attendance_rate"],
        persistent_attendance_event_count=count(AttendanceEvent, *attendance_conditions),
        source_count=count(DataSource, DataSource.institution_id == principal.institution_id),
        pending_import_count=(
            count(ImportBatch, ImportBatch.institution_id == principal.institution_id, ImportBatch.status == "pending")
            if has_full_institution_scope(principal) else 0
        ),
        document_count=int(db.scalar(document_query) or 0),
        intervention_count=count(Intervention, *intervention_conditions),
        dataset_notice=(
            "Bundled programme KPIs are synthetic. Registered tenant records are stored separately and must be validated before operational use."
            if principal.demo_mode else
            "Metrics use registered programme, cohort and approved attendance records within your authorised scope. Source quality and indicator definitions still require institutional validation."
        ),
    )


@app.get("/api/v1/insights", response_model=list[Insight], tags=["intelligence"])
def get_insights(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    return tenant_intelligence(principal, db).insights()


@app.get("/api/v1/forecast/{cohort_id}", response_model=AttendanceForecast, tags=["intelligence"])
def get_attendance_forecast(
    cohort_id: str,
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    horizon: Annotated[int, Query(ge=1, le=12)] = 4,
    db: Session = Depends(get_db),
):
    engine = tenant_intelligence(principal, db)
    known = {cohort["cohort_id"] for cohort in engine.dataset["cohorts"]}
    if cohort_id not in known:
        raise HTTPException(status_code=404, detail="Unknown cohort_id in this institution")
    return engine.forecast_attendance(cohort_id, horizon)


@app.post("/api/v1/data/validate", response_model=DataValidationResponse, tags=["data"])
def validate_data(
    request: DataValidationRequest,
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
):
    return intelligence.validate_attendance_records(request.records)


@app.get("/api/v1/programmes", response_model=list[ProgrammeOut], tags=["institution"])
def get_programmes(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    return list(db.scalars(visible_programmes_query(principal).order_by(Programme.name)).all())


@app.post("/api/v1/programmes", response_model=ProgrammeOut, status_code=201, tags=["institution"])
def post_programme(
    request: ProgrammeCreate,
    principal: Annotated[Principal, Depends(require_roles(*WRITE_ROLES))],
    db: Session = Depends(get_db),
):
    if not has_full_institution_scope(principal) and request.department_id != principal.department_id:
        raise HTTPException(status_code=403, detail="You can only create programmes in your assigned department")
    if not has_full_institution_scope(principal) and not request.department_id:
        raise HTTPException(status_code=422, detail="department_id is required for department-scoped users")
    if request.department_id:
        department = db.scalar(select(Department).where(Department.id == request.department_id, Department.institution_id == principal.institution_id))
        if not department:
            raise HTTPException(status_code=404, detail="Department not found in this institution")
    item = Programme(institution_id=principal.institution_id, **request.model_dump())
    db.add(item)
    try:
        db.flush()
        log_audit(db, principal.institution_id, principal.user_id, "programme.created", "programme", item.id, {"code": item.code})
        db.commit()
        db.refresh(item)
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Programme code already exists in this institution") from exc
    return item


@app.get("/api/v1/cohorts", response_model=list[CohortOut], tags=["institution"])
def get_cohorts(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    engine = tenant_intelligence(principal, db)
    overview_rows = {row["cohort_id"]: row for row in engine.overview()["cohorts"]}
    records = db.scalars(visible_cohorts_query(principal).order_by(Cohort.name)).all()
    output = []
    for record in records:
        stats = overview_rows.get(record.code, {})
        output.append(CohortOut(
            cohort_id=record.code, programme_id=record.programme_id, name=record.name,
            enrolled_count=record.enrolled_count, capacity=record.capacity, status=record.status,
            session_count=stats.get("session_count", 0),
            overall_attendance_rate=stats.get("overall_attendance_rate"),
            latest_attendance_rate=stats.get("latest_attendance_rate"),
        ))
    return output


@app.post("/api/v1/cohorts", response_model=CohortOut, status_code=201, tags=["institution"])
def post_cohort(
    request: CohortCreate,
    principal: Annotated[Principal, Depends(require_roles(*WRITE_ROLES))],
    db: Session = Depends(get_db),
):
    programme = db.scalar(visible_programmes_query(principal).where(Programme.id == request.programme_id))
    if not programme:
        raise HTTPException(status_code=404, detail="Programme not found in this institution")
    item = Cohort(
        institution_id=principal.institution_id,
        programme_id=request.programme_id, code=request.cohort_id, name=request.name,
        enrolled_count=request.enrolled_count, capacity=request.capacity,
    )
    db.add(item)
    try:
        db.flush()
        log_audit(db, principal.institution_id, principal.user_id, "cohort.created", "cohort", item.id, {"programme_id": item.programme_id, "cohort_code": item.code})
        db.commit()
        db.refresh(item)
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Cohort code already exists in this institution") from exc
    return CohortOut(cohort_id=item.code, programme_id=item.programme_id, name=item.name, enrolled_count=item.enrolled_count, capacity=item.capacity, status=item.status)


@app.get("/api/v1/departments", tags=["institution"])
def get_departments(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    department_query = select(Department).where(Department.institution_id == principal.institution_id)
    if not has_full_institution_scope(principal):
        if principal.department_id:
            department_query = department_query.where(Department.id == principal.department_id)
        else:
            department_query = department_query.where(Department.id == "__no_department_scope__")
    rows = db.scalars(department_query.order_by(Department.name))
    return [{"id": row.id, "code": row.code, "name": row.name} for row in rows]


@app.post("/api/v1/departments", status_code=201, tags=["institution"])
def post_department(
    request: DepartmentCreate,
    principal: Annotated[Principal, Depends(require_roles("admin", "executive"))],
    db: Session = Depends(get_db),
):
    institution = db.get(Institution, principal.institution_id)
    if institution is None:
        raise HTTPException(status_code=409, detail="Institution tenant has not been provisioned. Run the trusted institution provisioning script first.")
    item = Department(
        id=str(uuid4()), institution_id=principal.institution_id,
        code=request.code, name=request.name,
    )
    db.add(item)
    try:
        db.flush()
        log_audit(db, principal.institution_id, principal.user_id, "department.created", "department", item.id, {"code": item.code})
        db.commit()
        db.refresh(item)
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Department code already exists in this institution") from exc
    return {"id": item.id, "code": item.code, "name": item.name}


@app.get("/api/v1/sources", response_model=list[DataSourceOut], tags=["data sources"])
def get_sources(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    return list(db.scalars(select(DataSource).where(DataSource.institution_id == principal.institution_id).order_by(DataSource.created_at.desc())).all())


@app.post("/api/v1/sources", response_model=DataSourceOut, status_code=201, tags=["data sources"])
def post_source(
    request: DataSourceCreate,
    principal: Annotated[Principal, Depends(require_roles(*WRITE_ROLES))],
    db: Session = Depends(get_db),
):
    item = DataSource(institution_id=principal.institution_id, **request.model_dump())
    db.add(item)
    try:
        db.flush()
        log_audit(db, principal.institution_id, principal.user_id, "source.created", "data_source", item.id, {"name": item.name, "kind": item.kind})
        db.commit()
        db.refresh(item)
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="A source with this name already exists") from exc
    return item


@app.get("/api/v1/imports", response_model=list[ImportBatchOut], tags=["data imports"])
def get_imports(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    rows = db.scalars(select(ImportBatch).where(ImportBatch.institution_id == principal.institution_id).order_by(ImportBatch.created_at.desc()).limit(100)).all()
    return [_batch_out(row) for row in rows if batch_in_scope(row, principal, db)]


@app.post("/api/v1/imports/preview", response_model=ImportBatchOut, status_code=201, tags=["data imports"])
async def preview_import(
    file: Annotated[UploadFile, File(...)],
    source_id: Annotated[str, Form(...)],
    principal: Annotated[Principal, Depends(require_roles(*WRITE_ROLES))],
    db: Session = Depends(get_db),
):
    source = db.scalar(select(DataSource).where(DataSource.id == source_id, DataSource.institution_id == principal.institution_id, DataSource.enabled == 1))
    if source is None:
        raise HTTPException(status_code=404, detail="Enabled source not found in this institution")
    content = await file.read(settings.max_upload_bytes + 1)
    if len(content) > settings.max_upload_bytes:
        raise HTTPException(status_code=413, detail=f"File exceeds {settings.max_upload_bytes // (1024 * 1024)} MB limit")
    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=415, detail="Only CSV imports are supported in this prototype")
    digest = hashlib.sha256(content).hexdigest()
    existing = db.scalar(select(ImportBatch).where(
        ImportBatch.institution_id == principal.institution_id,
        ImportBatch.file_sha256 == digest,
        ImportBatch.source_id == source.id,
    ))
    if existing:
        raise HTTPException(status_code=409, detail="This exact file has already been staged for this source")
    try:
        decoded = content.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(decoded))
        required = {"event_id", "cohort_id", "session_date", "enrolled_count", "attendance_count"}
        headers = set(reader.fieldnames or [])
        missing = sorted(required - headers)
        if missing:
            raise HTTPException(status_code=422, detail={"message": "CSV is missing required columns", "missing": missing})
        accepted = []
        errors = []
        seen = set()
        total = 0
        for index, raw in enumerate(reader, start=2):
            total += 1
            record = dict(raw)
            record["source_id"] = source.id
            try:
                parsed = AttendanceSession.model_validate(record)
                cohort_query = (
                    select(Cohort.id)
                    .join(Programme, Cohort.programme_id == Programme.id)
                    .where(Cohort.code == parsed.cohort_id, Cohort.institution_id == principal.institution_id, Cohort.status == "active", Programme.institution_id == principal.institution_id, Programme.active == 1)
                )
                if not has_full_institution_scope(principal):
                    if not principal.department_id:
                        cohort_query = cohort_query.where(Programme.id == "__no_department_scope__")
                    else:
                        cohort_query = cohort_query.where(Programme.department_id == principal.department_id)
                cohort = db.scalar(cohort_query)
                if cohort is None:
                    raise ValueError("cohort_id is not registered and active in this institution")
                registered_cohort = db.scalar(
                    select(Cohort).join(Programme, Cohort.programme_id == Programme.id)
                    .where(Cohort.code == parsed.cohort_id, Cohort.institution_id == principal.institution_id, Programme.institution_id == principal.institution_id)
                )
                if registered_cohort and parsed.enrolled_count > registered_cohort.capacity:
                    raise ValueError("enrolled_count exceeds the registered cohort capacity")
                if parsed.event_id in seen:
                    raise ValueError("Duplicate event_id within this file")
                seen.add(parsed.event_id)
                accepted.append(parsed.model_dump(mode="json"))
            except Exception as exc:
                errors.append({"row": index, "message": str(exc)[:500]})
        batch = ImportBatch(
            institution_id=principal.institution_id,
            source_id=source.id,
            file_name=file.filename[:255],
            file_sha256=digest,
            status="pending",
            total_rows=total,
            accepted_rows=len(accepted),
            rejected_rows=len(errors),
            staged_records_json=json.dumps(accepted),
            errors_json=json.dumps(errors),
            created_by=principal.user_id,
        )
        db.add(batch)
        db.flush()
        log_audit(db, principal.institution_id, principal.user_id, "import.previewed", "import_batch", batch.id, {"file_name": batch.file_name, "accepted": len(accepted), "rejected": len(errors)})
        db.commit()
        db.refresh(batch)
        return batch
    except HTTPException:
        raise
    except UnicodeDecodeError as exc:
        raise HTTPException(status_code=422, detail="CSV must be UTF-8 encoded") from exc


@app.get("/api/v1/imports/{batch_id}", tags=["data imports"])
def get_import_detail(
    batch_id: str,
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    batch = db.scalar(select(ImportBatch).where(ImportBatch.id == batch_id, ImportBatch.institution_id == principal.institution_id))
    if not batch or not batch_in_scope(batch, principal, db):
        raise HTTPException(status_code=404, detail="Import batch not found")
    return {**_batch_out(batch).model_dump(mode="json"), "errors": json.loads(batch.errors_json)}


@app.post("/api/v1/imports/{batch_id}/approve", tags=["data imports"])
def approve_import(
    batch_id: str,
    principal: Annotated[Principal, Depends(require_roles(*APPROVE_ROLES))],
    db: Session = Depends(get_db),
):
    batch = db.scalar(select(ImportBatch).where(ImportBatch.id == batch_id, ImportBatch.institution_id == principal.institution_id))
    if not batch:
        raise HTTPException(status_code=404, detail="Import batch not found")
    if batch.status != "pending":
        raise HTTPException(status_code=409, detail=f"Import cannot be approved from status '{batch.status}'")
    staged = json.loads(batch.staged_records_json)
    inserted = 0
    duplicates = 0
    for record in staged:
        exists = db.scalar(select(AttendanceEvent.id).where(
            AttendanceEvent.institution_id == principal.institution_id,
            AttendanceEvent.event_id == record["event_id"],
        ))
        if exists:
            duplicates += 1
            continue
        db.add(AttendanceEvent(
            institution_id=principal.institution_id,
            event_id=record["event_id"],
            cohort_id=record["cohort_id"],
            session_date=datetime.strptime(record["session_date"], "%Y-%m-%d").date(),
            enrolled_count=record["enrolled_count"],
            attendance_count=record["attendance_count"],
            source_id=batch.source_id,
            batch_id=batch.id,
            provenance_json=json.dumps({"file_name": batch.file_name, "sha256": batch.file_sha256, "row_origin": "approved_import"}),
        ))
        inserted += 1
    batch.status = "approved"
    batch.approved_by = principal.user_id
    batch.approved_at = datetime.now(timezone.utc)
    log_audit(db, principal.institution_id, principal.user_id, "import.approved", "import_batch", batch.id, {"inserted": inserted, "duplicates_skipped": duplicates})
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Import conflicted with a concurrent event ingestion; reload and review the batch") from exc
    return {"batch_id": batch.id, "status": batch.status, "inserted_count": inserted, "duplicate_events_skipped": duplicates, "note": "Import approval persists validated events; no source data are overwritten."}


@app.get("/api/v1/attendance/events", tags=["data"])
def get_attendance_events(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    limit: Annotated[int, Query(ge=1, le=500)] = 100,
    db: Session = Depends(get_db),
):
    event_query = select(AttendanceEvent).where(AttendanceEvent.institution_id == principal.institution_id)
    if not has_full_institution_scope(principal):
        codes = visible_cohort_codes(principal, db)
        event_query = event_query.where(AttendanceEvent.cohort_id.in_(codes)) if codes else event_query.where(AttendanceEvent.id == "__no_department_scope__")
    rows = db.scalars(event_query.order_by(AttendanceEvent.session_date.desc()).limit(limit))
    return [{
        "event_id": r.event_id, "cohort_id": r.cohort_id, "session_date": r.session_date,
        "enrolled_count": r.enrolled_count, "attendance_count": r.attendance_count,
        "source_id": r.source_id, "batch_id": r.batch_id,
    } for r in rows]


@app.get("/api/v1/indicators", response_model=list[IndicatorOut], tags=["indicators"])
def get_indicators(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    return list(db.scalars(select(IndicatorDefinition).where(IndicatorDefinition.institution_id == principal.institution_id, IndicatorDefinition.active == 1).order_by(IndicatorDefinition.code, IndicatorDefinition.version.desc())).all())


@app.post("/api/v1/indicators", response_model=IndicatorOut, status_code=201, tags=["indicators"])
def post_indicator(
    request: IndicatorCreate,
    principal: Annotated[Principal, Depends(require_roles(*WRITE_ROLES))],
    db: Session = Depends(get_db),
):
    if not has_full_institution_scope(principal):
        raise HTTPException(status_code=403, detail="Only institution-wide roles can publish indicator definitions")
    latest = db.scalar(select(func.max(IndicatorDefinition.version)).where(IndicatorDefinition.institution_id == principal.institution_id, IndicatorDefinition.code == request.code))
    version = int(latest or 0) + 1
    db.query(IndicatorDefinition).filter(
        IndicatorDefinition.institution_id == principal.institution_id,
        IndicatorDefinition.code == request.code,
        IndicatorDefinition.active == 1,
    ).update({"active": 0})
    item = IndicatorDefinition(institution_id=principal.institution_id, version=version, **request.model_dump())
    db.add(item)
    db.flush()
    log_audit(db, principal.institution_id, principal.user_id, "indicator.version_created", "indicator", item.id, {"code": item.code, "version": version})
    db.commit()
    db.refresh(item)
    return item


@app.get("/api/v1/knowledge/documents", tags=["knowledge"])
def list_knowledge_documents(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    query = select(KnowledgeDocument).where(KnowledgeDocument.institution_id == principal.institution_id, KnowledgeDocument.status == "active")
    if not has_full_institution_scope(principal):
        if principal.department_id:
            query = query.where((KnowledgeDocument.visibility == "institution") | (KnowledgeDocument.department_id == principal.department_id))
        else:
            query = query.where(KnowledgeDocument.visibility == "institution")
    docs = db.scalars(query.order_by(KnowledgeDocument.created_at.desc())).all()
    return [{"id": d.id, "file_name": d.file_name, "mime_type": d.mime_type, "visibility": d.visibility, "department_id": d.department_id, "chunk_count": d.chunk_count, "created_at": d.created_at} for d in docs]


@app.post("/api/v1/knowledge/documents", status_code=201, tags=["knowledge"])
async def upload_knowledge_document(
    file: Annotated[UploadFile, File(...)],
    principal: Annotated[Principal, Depends(require_roles(*WRITE_ROLES))],
    db: Session = Depends(get_db),
    visibility: Annotated[str, Form()] = "institution",
    department_id: Annotated[str | None, Form()] = None,
):
    if visibility not in {"institution", "department"}:
        raise HTTPException(status_code=422, detail="visibility must be institution or department")
    if visibility == "department":
        if not department_id:
            raise HTTPException(status_code=422, detail="department_id is required for department visibility")
        department = db.scalar(select(Department).where(Department.id == department_id, Department.institution_id == principal.institution_id))
        if not department:
            raise HTTPException(status_code=404, detail="Department not found in this institution")
        if not has_full_institution_scope(principal) and principal.department_id != department_id:
            raise HTTPException(status_code=403, detail="You cannot upload documents to another department")
    else:
        if not has_full_institution_scope(principal):
            raise HTTPException(status_code=403, detail="Department-scoped users may only upload department-visible documents")
        department_id = None
    content = await file.read(settings.max_upload_bytes + 1)
    if len(content) > settings.max_upload_bytes:
        raise HTTPException(status_code=413, detail=f"Document exceeds {settings.max_upload_bytes // (1024 * 1024)} MB limit")
    if not file.filename:
        raise HTTPException(status_code=422, detail="A file name is required")
    digest = hashlib.sha256(content).hexdigest()
    existing = db.scalar(select(KnowledgeDocument).where(KnowledgeDocument.institution_id == principal.institution_id, KnowledgeDocument.sha256 == digest))
    if existing:
        raise HTTPException(status_code=409, detail="This exact document already exists in the institution knowledge base")
    try:
        pages = extract_document(file.filename, content)
        chunks = chunk_pages(pages)
    except ValueError as exc:
        raise HTTPException(status_code=415, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail="The document could not be parsed or text could not be extracted") from exc
    if not chunks:
        raise HTTPException(status_code=422, detail="No extractable text was found in this document")
    if sum(len(chunk) for _, chunk in chunks) > 2_000_000:
        raise HTTPException(status_code=413, detail="Extracted text exceeds the processing limit")
    doc = KnowledgeDocument(
        institution_id=principal.institution_id,
        department_id=department_id,
        file_name=file.filename[:255],
        mime_type=file.content_type or "application/octet-stream",
        sha256=digest,
        visibility=visibility,
        status="active",
        chunk_count=len(chunks),
        uploaded_by=principal.user_id,
    )
    db.add(doc)
    db.flush()
    for index, (page, text) in enumerate(chunks):
        db.add(DocumentChunk(institution_id=principal.institution_id, document_id=doc.id, chunk_index=index, content=text, page_number=page))
    log_audit(db, principal.institution_id, principal.user_id, "knowledge_document.uploaded", "knowledge_document", doc.id, {"file_name": doc.file_name, "chunk_count": doc.chunk_count, "visibility": visibility})
    db.commit()
    return {"id": doc.id, "file_name": doc.file_name, "chunk_count": doc.chunk_count, "visibility": doc.visibility, "status": doc.status, "notice": "Document content is stored for institution-scoped retrieval. No external AI provider is used unless explicitly enabled."}


@app.post("/api/v1/knowledge/query", response_model=KnowledgeAnswer, tags=["knowledge"])
def query_knowledge(
    request: KnowledgeQuery,
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    sources = retrieve_chunks(db, principal, request.question, request.top_k)
    log_audit(db, principal.institution_id, principal.user_id, "knowledge.query", "knowledge_query", str(uuid4()), {"source_count": len(sources)})
    db.commit()
    answer, mode = answer_question(request.question, sources)
    source_models = [KnowledgeSource(
        citation=item["citation"], document_id=item["document_id"], file_name=item["file_name"],
        chunk_index=item["chunk_index"], snippet=item["snippet"], relevance=item["relevance"],
    ) for item in sources]
    return KnowledgeAnswer(
        answer=answer,
        answer_mode=mode,
        grounded=bool(sources),
        sources=source_models,
        limitations=[
            "Answers are restricted to documents the current user is permitted to access.",
            "Retrieval relevance is not proof that a source is complete, current or authoritative.",
            "External language-model processing is disabled by default; if enabled, retrieved document chunks are sent to the configured provider.",
        ],
    )


@app.get("/api/v1/audit", tags=["audit"])
def get_audit(
    principal: Annotated[Principal, Depends(require_roles("admin", "executive", "analyst"))],
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    db: Session = Depends(get_db),
):
    rows = db.scalars(select(AuditLog).where(AuditLog.institution_id == principal.institution_id).order_by(AuditLog.created_at.desc()).limit(limit))
    return [{"id": r.id, "actor_id": r.actor_id, "action": r.action, "entity_type": r.entity_type, "entity_id": r.entity_id, "details": json.loads(r.details_json), "created_at": r.created_at} for r in rows]


@app.get("/api/v1/interventions", response_model=list[InterventionOut], tags=["interventions"])
def get_interventions(
    principal: Annotated[Principal, Depends(require_roles(*READ_ROLES))],
    db: Session = Depends(get_db),
):
    query = select(Intervention).where(Intervention.institution_id == principal.institution_id)
    if not has_full_institution_scope(principal):
        codes = visible_cohort_codes(principal, db)
        query = query.where(Intervention.cohort_id.in_(codes)) if codes else query.where(Intervention.id == "__no_department_scope__")
    return list(db.scalars(query.order_by(Intervention.created_at.desc())).all())


@app.post("/api/v1/interventions", response_model=InterventionOut, status_code=status.HTTP_201_CREATED, tags=["interventions"])
def post_intervention(
    request: InterventionCreate,
    principal: Annotated[Principal, Depends(require_roles(*WRITE_ROLES))],
    db: Session = Depends(get_db),
):
    engine = tenant_intelligence(principal, db)
    known = {cohort["cohort_id"] for cohort in engine.dataset["cohorts"]}
    if request.cohort_id not in known:
        raise HTTPException(status_code=404, detail="Unknown cohort_id in this institution")
    try:
        baseline_rate, baseline_count = intervention_baseline(engine, request.cohort_id)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    item = create_intervention(
        db,
        institution_id=principal.institution_id,
        **request.model_dump(),
        status="proposed",
        baseline_attendance_rate=baseline_rate,
        baseline_session_count=baseline_count,
    )
    log_audit(db, principal.institution_id, principal.user_id, "intervention.created", "intervention", item.id, {"cohort_id": item.cohort_id})
    db.commit()
    db.refresh(item)
    return item


@app.post("/api/v1/interventions/{intervention_id}/implement", response_model=InterventionOut, tags=["interventions"])
def implement_intervention(
    intervention_id: str,
    principal: Annotated[Principal, Depends(require_roles(*APPROVE_ROLES))],
    db: Session = Depends(get_db),
):
    item = db.scalar(select(Intervention).where(Intervention.id == intervention_id, Intervention.institution_id == principal.institution_id))
    if item is None:
        raise HTTPException(status_code=404, detail="Intervention not found")
    if item.status != "proposed":
        raise HTTPException(status_code=409, detail="Only proposed interventions can be marked implemented")
    item.status = "active"
    item.implemented_at = datetime.now(timezone.utc)
    log_audit(db, principal.institution_id, principal.user_id, "intervention.implemented", "intervention", item.id)
    db.commit()
    db.refresh(item)
    return item


@app.post("/api/v1/interventions/{intervention_id}/evaluate", response_model=InterventionOut, tags=["interventions"])
def evaluate_intervention(
    intervention_id: str,
    request: InterventionEvaluationRequest,
    principal: Annotated[Principal, Depends(require_roles(*APPROVE_ROLES))],
    db: Session = Depends(get_db),
):
    item = db.scalar(select(Intervention).where(Intervention.id == intervention_id, Intervention.institution_id == principal.institution_id))
    if item is None:
        raise HTTPException(status_code=404, detail="Intervention not found")
    if item.status != "active":
        raise HTTPException(status_code=409, detail="Intervention must be active before evaluation")
    cohort = db.scalar(select(Cohort).where(Cohort.institution_id == principal.institution_id, Cohort.code == item.cohort_id, Cohort.status == "active"))
    if cohort is None:
        raise HTTPException(status_code=409, detail="The intervention cohort is no longer active in this institution")
    if request.enrolled_count != cohort.enrolled_count:
        raise HTTPException(status_code=422, detail="enrolled_count must match the registered cohort denominator")
    follow_up_rate = sum(request.follow_up_attendance_counts) / (len(request.follow_up_attendance_counts) * request.enrolled_count)
    change_pp = (follow_up_rate - item.baseline_attendance_rate) * 100
    item.follow_up_attendance_rate = follow_up_rate
    item.change_percentage_points = change_pp
    item.status = "evaluated"
    item.evidence_references = json.dumps(request.evidence_references)
    direction = "increased" if change_pp > 0 else "decreased" if change_pp < 0 else "did not change"
    item.evaluation_note = (
        f"Follow-up attendance {direction} by {abs(change_pp):.2f} percentage points compared with the recorded baseline. "
        "This descriptive comparison does not establish that the intervention caused the change; context and an appropriate evaluation design are required."
    )
    log_audit(db, principal.institution_id, principal.user_id, "intervention.evaluated", "intervention", item.id, {"change_percentage_points": round(change_pp, 2)})
    db.commit()
    db.refresh(item)
    return item
