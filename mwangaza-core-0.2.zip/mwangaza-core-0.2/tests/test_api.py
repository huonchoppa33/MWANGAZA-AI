from datetime import date, timedelta


def test_health_and_demo_are_explicitly_labelled(client):
    health = client.get("/api/v1/health")
    assert health.status_code == 200
    assert health.json()["status"] == "healthy"

    overview = client.get("/api/v1/demo/overview")
    assert overview.status_code == 200
    assert overview.json()["demo_only"] is True
    assert "not Swahilipot" in overview.json()["dataset_notice"]


def test_insights_detect_synthetic_attendance_pattern(client):
    response = client.get("/api/v1/insights")
    assert response.status_code == 200
    insights = response.json()
    assert any("COH-TECH-A" in item["insight_id"] for item in insights)
    assert all(item["human_review_required"] for item in insights)


def test_forecast_is_experimental_and_has_limitations(client):
    response = client.get("/api/v1/forecast/COH-TECH-A?horizon=3")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "experimental"
    assert len(body["forecast"]) == 3
    assert body["limitations"]


def test_unknown_cohort_returns_404(client):
    assert client.get("/api/v1/forecast/not-a-cohort").status_code == 404


def test_data_validation_reports_duplicates_and_invalid_counts(client):
    payload = {
        "records": [
            {"event_id": "E1", "cohort_id": "C1", "session_date": "2026-10-01", "attendance_count": 8, "enrolled_count": 10, "source_id": "TEST"},
            {"event_id": "E1", "cohort_id": "C1", "session_date": "2026-10-08", "attendance_count": 8, "enrolled_count": 10, "source_id": "TEST"},
            {"event_id": "E2", "cohort_id": "C1", "session_date": "2026-10-15", "attendance_count": 12, "enrolled_count": 10, "source_id": "TEST"},
        ]
    }
    response = client.post("/api/v1/data/validate", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["accepted_count"] == 1
    assert body["rejected_count"] == 2
    assert body["duplicate_event_ids"] == ["E1"]
    assert body["note"].startswith("Validation only")


def test_intervention_lifecycle_preserves_non_causal_warning(client):
    create_payload = {
        "title": "Review technology cohort session timing",
        "cohort_id": "COH-TECH-A",
        "management_question": "Could session timing contribute to lower recent attendance?",
        "hypothesis": "A revised session time may improve attendance if scheduling is a key barrier.",
        "planned_action": "Run a manager-approved timetable adjustment for the next three sessions.",
        "owner_role": "Programme Manager",
        "review_date": str(date.today() + timedelta(days=30)),
    }
    created = client.post("/api/v1/interventions", json=create_payload)
    assert created.status_code == 201
    item = created.json()
    assert item["status"] == "proposed"
    assert item["baseline_session_count"] == 3

    implemented = client.post(f"/api/v1/interventions/{item['id']}/implement")
    assert implemented.status_code == 200
    assert implemented.json()["status"] == "active"

    evaluated = client.post(
        f"/api/v1/interventions/{item['id']}/evaluate",
        json={"follow_up_attendance_counts": [25, 26, 27], "enrolled_count": 32, "evidence_references": ["TEST-REPORT-01"]},
    )
    assert evaluated.status_code == 200
    result = evaluated.json()
    assert result["status"] == "evaluated"
    assert result["follow_up_attendance_rate"] > 0
    assert "does not establish" in result["evaluation_note"]


def test_sources_csv_import_preview_and_approval_are_persistent_and_idempotent(client):
    identity = client.get("/api/v1/identity")
    assert identity.status_code == 200
    assert identity.json()["institution_id"] == "demo-institution"

    sources = client.get("/api/v1/sources")
    assert sources.status_code == 200
    source_id = next(item["id"] for item in sources.json() if item["name"] == "Manual CSV upload")

    programme_id = client.get("/api/v1/programmes").json()[0]["id"]
    cohort = client.post("/api/v1/cohorts", json={"cohort_id": "COH-TEST", "programme_id": programme_id, "name": "Test cohort", "enrolled_count": 20, "capacity": 25})
    assert cohort.status_code == 201, cohort.text
    csv_data = (
        "event_id,cohort_id,session_date,enrolled_count,attendance_count\n"
        "IMPORT-001,COH-TEST,2026-11-01,20,17\n"
        "IMPORT-002,COH-TEST,2026-11-08,20,18\n"
        "IMPORT-003,COH-TEST,2026-11-15,20,25\n"
    )
    preview = client.post(
        "/api/v1/imports/preview",
        data={"source_id": source_id},
        files={"file": ("attendance.csv", csv_data, "text/csv")},
    )
    assert preview.status_code == 201, preview.text
    batch = preview.json()
    assert batch["status"] == "pending"
    assert batch["accepted_rows"] == 2
    assert batch["rejected_rows"] == 1

    approved = client.post(f"/api/v1/imports/{batch['id']}/approve")
    assert approved.status_code == 200, approved.text
    assert approved.json()["inserted_count"] == 2
    assert approved.json()["duplicate_events_skipped"] == 0

    events = client.get("/api/v1/attendance/events")
    assert events.status_code == 200
    assert {item["event_id"] for item in events.json()} == {"IMPORT-001", "IMPORT-002"}
    assert client.post(f"/api/v1/imports/{batch['id']}/approve").status_code == 409


def test_indicator_definitions_are_versioned(client):
    payload = {
        "code": "COHORT_COMPLETION",
        "name": "Cohort completion rate",
        "description": "Share of enrolled participants meeting the approved completion definition.",
        "numerator_definition": "Participants recorded as completed under the approved programme rule.",
        "denominator_definition": "Participants enrolled at the defined cohort start date.",
        "unit": "percentage",
        "owner_role": "M&E Officer",
    }
    first = client.post("/api/v1/indicators", json=payload)
    assert first.status_code == 201, first.text
    assert first.json()["version"] == 1
    second = client.post("/api/v1/indicators", json=payload)
    assert second.status_code == 201, second.text
    assert second.json()["version"] == 2
    active = client.get("/api/v1/indicators").json()
    assert len(active) == 1
    assert active[0]["version"] == 2


def test_knowledge_upload_and_retrieval_are_source_grounded(client):
    text = (
        "Programme review policy. Every programme review must consider attendance, completion, "
        "learning assessments and participant feedback. Managers should document the evidence "
        "behind every proposed intervention and review the results after implementation. "
        "A before-and-after comparison alone does not establish causation."
    )
    upload = client.post(
        "/api/v1/knowledge/documents",
        data={"visibility": "institution"},
        files={"file": ("programme-review-policy.txt", text, "text/plain")},
    )
    assert upload.status_code == 201, upload.text
    assert upload.json()["chunk_count"] >= 1

    answer = client.post(
        "/api/v1/knowledge/query",
        json={"question": "What should programme reviews consider?", "top_k": 3},
    )
    assert answer.status_code == 200, answer.text
    body = answer.json()
    assert body["grounded"] is True
    assert body["sources"]
    assert body["sources"][0]["file_name"] == "programme-review-policy.txt"
    assert "attendance" in body["answer"].lower()

    duplicate = client.post(
        "/api/v1/knowledge/documents",
        data={"visibility": "institution"},
        files={"file": ("programme-review-policy.txt", text, "text/plain")},
    )
    assert duplicate.status_code == 409


def test_dashboard_summary_reports_synthetic_and_persistent_data_separately(client):
    response = client.get("/api/v1/dashboard/summary")
    assert response.status_code == 200
    body = response.json()
    assert body["demo_only"] is True
    assert "synthetic" in body["dataset_notice"].lower()
    assert body["source_count"] >= 2
    assert body["persistent_attendance_event_count"] == 0


def test_tenant_scoping_and_department_document_permissions(client):
    from app.auth import Principal, current_principal
    from app.main import app

    upload = client.post(
        "/api/v1/knowledge/documents",
        data={"visibility": "department", "department_id": "dept-technology"},
        files={"file": ("restricted-notes.txt", "Technology department internal review notes about equipment scheduling.", "text/plain")},
    )
    assert upload.status_code == 201, upload.text

    app.dependency_overrides[current_principal] = lambda: Principal(
        user_id="staff-without-department", institution_id="demo-institution", role="staff", department_id=None
    )
    try:
        docs = client.get("/api/v1/knowledge/documents")
        assert docs.status_code == 200
        assert all(doc["file_name"] != "restricted-notes.txt" for doc in docs.json())
        query = client.post("/api/v1/knowledge/query", json={"question": "What do the technology notes say about equipment?"})
        assert query.status_code == 200
        assert query.json()["grounded"] is False

        app.dependency_overrides[current_principal] = lambda: Principal(
            user_id="other-tenant-admin", institution_id="other-institution", role="admin", department_id=None
        )
        assert client.get("/api/v1/sources").json() == []
        assert client.get("/api/v1/knowledge/documents").json() == []
    finally:
        app.dependency_overrides.pop(current_principal, None)


def test_import_skips_event_ids_already_stored_in_tenant(client):
    source_id = next(item["id"] for item in client.get("/api/v1/sources").json() if item["name"] == "Manual CSV upload")
    programme_id = client.get("/api/v1/programmes").json()[0]["id"]
    cohort = client.post("/api/v1/cohorts", json={"cohort_id": "COH-Z", "programme_id": programme_id, "name": "Duplicate test cohort", "enrolled_count": 10, "capacity": 10})
    assert cohort.status_code == 201
    first_csv = "event_id,cohort_id,session_date,enrolled_count,attendance_count\nDUP-001,COH-Z,2026-11-01,10,8\n"
    first = client.post("/api/v1/imports/preview", data={"source_id": source_id}, files={"file": ("first.csv", first_csv, "text/csv")})
    assert first.status_code == 201
    assert client.post(f"/api/v1/imports/{first.json()['id']}/approve").json()["inserted_count"] == 1

    second_csv = "event_id,cohort_id,session_date,enrolled_count,attendance_count\nDUP-001,COH-Z,2026-11-01,10,8\nDUP-002,COH-Z,2026-11-08,10,9\n"
    second = client.post("/api/v1/imports/preview", data={"source_id": source_id}, files={"file": ("second.csv", second_csv, "text/csv")})
    assert second.status_code == 201
    result = client.post(f"/api/v1/imports/{second.json()['id']}/approve")
    assert result.status_code == 200
    assert result.json()["inserted_count"] == 1
    assert result.json()["duplicate_events_skipped"] == 1


def test_authenticated_tenant_dashboard_uses_only_registered_tenant_data(client):
    from app.auth import Principal, current_principal
    from app.database import Institution, get_db
    from app.main import app

    session_generator = app.dependency_overrides[get_db]()
    db_session = next(session_generator)
    try:
        db_session.add(Institution(id="institution-alpha", name="Alpha Innovation Hub", is_demo=0))
        db_session.commit()
    finally:
        try:
            next(session_generator)
        except StopIteration:
            pass

    app.dependency_overrides[current_principal] = lambda: Principal(
        user_id="alpha-admin", institution_id="institution-alpha", role="admin", department_id=None
    )
    try:
        programme = client.post("/api/v1/programmes", json={"code": "ALPHA_TECH", "name": "Alpha Technology Programme"})
        assert programme.status_code == 201, programme.text
        cohort = client.post("/api/v1/cohorts", json={
            "cohort_id": "ALPHA_COHORT_01", "programme_id": programme.json()["id"],
            "name": "Alpha Cohort 01", "enrolled_count": 15, "capacity": 20,
        })
        assert cohort.status_code == 201, cohort.text
        source = client.post("/api/v1/sources", json={"name": "Alpha attendance export", "kind": "file", "description": "Approved Alpha cohort exports", "owner_role": "Data Steward"})
        assert source.status_code == 201, source.text
        csv_data = (
            "event_id,cohort_id,session_date,enrolled_count,attendance_count\n"
            "ALPHA-EVT-01,ALPHA_COHORT_01,2026-10-01,15,12\n"
            "ALPHA-EVT-02,ALPHA_COHORT_01,2026-10-08,15,13\n"
            "ALPHA-EVT-03,ALPHA_COHORT_01,2026-10-15,15,14\n"
            "ALPHA-EVT-04,ALPHA_COHORT_01,2026-10-22,15,13\n"
        )
        preview = client.post("/api/v1/imports/preview", data={"source_id": source.json()["id"]}, files={"file": ("alpha.csv", csv_data, "text/csv")})
        assert preview.status_code == 201, preview.text
        approved = client.post(f"/api/v1/imports/{preview.json()['id']}/approve")
        assert approved.status_code == 200

        summary = client.get("/api/v1/dashboard/summary")
        assert summary.status_code == 200
        body = summary.json()
        assert body["institution_name"] == "Alpha Innovation Hub"
        assert body["demo_only"] is False
        assert body["programme_count"] == 1
        assert body["cohort_count"] == 1
        assert body["attendance_session_count"] == 4
        assert body["persistent_attendance_event_count"] == 4
        assert abs(body["overall_attendance_rate"] - (52 / 60)) < 0.001
        cohort_rows = client.get("/api/v1/cohorts").json()
        assert cohort_rows[0]["cohort_id"] == "ALPHA_COHORT_01"
        assert cohort_rows[0]["session_count"] == 4
    finally:
        app.dependency_overrides.pop(current_principal, None)


def test_csv_import_rejects_unregistered_cohort(client):
    source_id = next(item["id"] for item in client.get("/api/v1/sources").json() if item["name"] == "Manual CSV upload")
    csv_data = "event_id,cohort_id,session_date,enrolled_count,attendance_count\nUNKNOWN-01,NOT-REGISTERED,2026-11-01,10,8\n"
    response = client.post("/api/v1/imports/preview", data={"source_id": source_id}, files={"file": ("unknown.csv", csv_data, "text/csv")})
    assert response.status_code == 201
    assert response.json()["accepted_rows"] == 0
    assert response.json()["rejected_rows"] == 1
    detail = client.get(f"/api/v1/imports/{response.json()['id']}").json()
    assert "not registered" in detail["errors"][0]["message"]


def test_department_scoped_principal_cannot_read_or_write_other_departments(client):
    from app.auth import Principal, current_principal
    from app.main import app

    all_programmes = client.get("/api/v1/programmes").json()
    technology = next(item for item in all_programmes if item["code"] == "PRG-TECH")
    creative = next(item for item in all_programmes if item["code"] == "PRG-CREAT")

    app.dependency_overrides[current_principal] = lambda: Principal(
        user_id="tech-manager", institution_id="demo-institution", role="programme_manager",
        department_id="dept-technology", demo_mode=False,
    )
    try:
        programmes = client.get("/api/v1/programmes")
        assert programmes.status_code == 200
        assert [item["code"] for item in programmes.json()] == ["PRG-TECH"]

        cohorts = client.get("/api/v1/cohorts")
        assert cohorts.status_code == 200
        assert {item["cohort_id"] for item in cohorts.json()} == {"COH-TECH-A"}

        forbidden_programme = client.post("/api/v1/programmes", json={
            "code": "CROSS_DEPT", "name": "Cross department programme", "department_id": "dept-creative"
        })
        assert forbidden_programme.status_code == 403

        forbidden_cohort = client.post("/api/v1/cohorts", json={
            "cohort_id": "CROSS_COHORT", "programme_id": creative["id"],
            "name": "Cross department cohort", "enrolled_count": 10, "capacity": 12,
        })
        assert forbidden_cohort.status_code == 404

        departments = client.get("/api/v1/departments").json()
        assert [item["id"] for item in departments] == ["dept-technology"]

        source_id = next(item["id"] for item in client.get("/api/v1/sources").json() if item["name"] == "Manual CSV upload")
        csv_data = (
            "event_id,cohort_id,session_date,enrolled_count,attendance_count\n"
            "TECH-ONLY-01,COH-TECH-A,2026-11-01,32,28\n"
            "CREATIVE-LEAK-01,COH-CREAT-B,2026-11-01,24,20\n"
        )
        preview = client.post(
            "/api/v1/imports/preview", data={"source_id": source_id},
            files={"file": ("department-scope.csv", csv_data, "text/csv")},
        )
        assert preview.status_code == 201, preview.text
        assert preview.json()["accepted_rows"] == 1
        assert preview.json()["rejected_rows"] == 1

        events = client.get("/api/v1/attendance/events").json()
        assert events == []  # Pending imports are not visible as persisted attendance events.

        global_doc = client.post(
            "/api/v1/knowledge/documents", data={"visibility": "institution"},
            files={"file": ("institution-wide.txt", "Institution-wide policy content.", "text/plain")},
        )
        assert global_doc.status_code == 403
    finally:
        app.dependency_overrides.pop(current_principal, None)


def test_department_scoped_user_without_department_has_no_programme_data(client):
    from app.auth import Principal, current_principal
    from app.main import app

    app.dependency_overrides[current_principal] = lambda: Principal(
        user_id="unassigned-staff", institution_id="demo-institution", role="staff",
        department_id=None, demo_mode=False,
    )
    try:
        assert client.get("/api/v1/programmes").json() == []
        assert client.get("/api/v1/cohorts").json() == []
        assert client.get("/api/v1/attendance/events").json() == []
        summary = client.get("/api/v1/dashboard/summary")
        assert summary.status_code == 200
        assert summary.json()["programme_count"] == 0
        assert summary.json()["cohort_count"] == 0
        assert summary.json()["persistent_attendance_event_count"] == 0
    finally:
        app.dependency_overrides.pop(current_principal, None)



def test_department_scope_filters_dashboard_events_and_interventions(client):
    from app.auth import Principal, current_principal
    from app.main import app

    source_id = next(item["id"] for item in client.get("/api/v1/sources").json() if item["name"] == "Manual CSV upload")
    csv_data = (
        "event_id,cohort_id,session_date,enrolled_count,attendance_count\n"
        "TECH-SCOPE-01,COH-TECH-A,2026-11-03,32,28\n"
        "CREATIVE-SCOPE-01,COH-CREAT-B,2026-11-03,24,12\n"
    )
    preview = client.post("/api/v1/imports/preview", data={"source_id": source_id}, files={"file": ("scope-events.csv", csv_data, "text/csv")})
    assert preview.status_code == 201
    approval = client.post(f"/api/v1/imports/{preview.json()['id']}/approve")
    assert approval.status_code == 200

    creative_intervention = client.post("/api/v1/interventions", json={
        "title": "Review creative cohort attendance",
        "cohort_id": "COH-CREAT-B",
        "management_question": "What may explain lower attendance in the creative cohort?",
        "hypothesis": "A scheduling change may address a possible participation barrier.",
        "planned_action": "Review the schedule with the programme team and test an approved adjustment.",
        "owner_role": "Programme Manager",
        "review_date": str(date.today() + timedelta(days=30)),
    })
    assert creative_intervention.status_code == 201, creative_intervention.text

    app.dependency_overrides[current_principal] = lambda: Principal(
        user_id="technology-manager", institution_id="demo-institution", role="programme_manager",
        department_id="dept-technology", demo_mode=False,
    )
    try:
        summary = client.get("/api/v1/dashboard/summary")
        assert summary.status_code == 200
        body = summary.json()
        assert body["programme_count"] == 1
        assert body["cohort_count"] == 1
        assert body["persistent_attendance_event_count"] == 1
        assert abs(body["overall_attendance_rate"] - (28 / 32)) < 0.001

        events = client.get("/api/v1/attendance/events").json()
        assert [item["event_id"] for item in events] == ["TECH-SCOPE-01"]

        interventions = client.get("/api/v1/interventions").json()
        assert all(item["cohort_id"] == "COH-TECH-A" for item in interventions)
    finally:
        app.dependency_overrides.pop(current_principal, None)


def test_administrator_can_register_department_and_duplicate_is_rejected(client):
    created = client.post("/api/v1/departments", json={"code": "RESEARCH", "name": "Research and Evaluation"})
    assert created.status_code == 201, created.text
    department = created.json()
    assert department["code"] == "RESEARCH"
    assert department["id"]

    duplicate = client.post("/api/v1/departments", json={"code": "RESEARCH", "name": "Research and Evaluation"})
    assert duplicate.status_code == 409

    rows = client.get("/api/v1/departments").json()
    assert any(row["id"] == department["id"] for row in rows)


def test_department_scoped_role_cannot_create_department(client):
    from app.auth import Principal, current_principal
    from app.main import app

    app.dependency_overrides[current_principal] = lambda: Principal(
        user_id="tech-manager", institution_id="demo-institution", role="programme_manager",
        department_id="dept-technology", demo_mode=False,
    )
    try:
        response = client.post("/api/v1/departments", json={"code": "NEW_DEPT", "name": "New Department"})
        assert response.status_code == 403
    finally:
        app.dependency_overrides.pop(current_principal, None)
