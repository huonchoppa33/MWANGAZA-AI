from app.engine import IntelligenceEngine


def test_imported_dataset_insights_are_not_mislabelled_as_demo_data():
    dataset = {
        "demo_only": False,
        "programmes": [{"programme_id": "P-001", "name": "Registered programme"}],
        "cohorts": [{
            "cohort_id": "C-001",
            "programme_id": "P-001",
            "name": "Registered cohort",
            "enrolled_count": 10,
            "capacity": 12,
        }],
        "attendance_sessions": [
            {
                "event_id": f"EV-{index}",
                "cohort_id": "C-001",
                "session_date": f"2026-10-{index * 3:02d}",
                "enrolled_count": 10,
                "attendance_count": 6,
            }
            for index in range(1, 5)
        ],
        "resources": [],
    }
    engine = IntelligenceEngine(dataset)

    assert engine.overview()["demo_only"] is False
    insights = engine.insights()
    assert insights
    assert all(item.demo_only is False for item in insights)
    assert all("synthetic" not in " ".join(item.limitations).lower() for item in insights)
