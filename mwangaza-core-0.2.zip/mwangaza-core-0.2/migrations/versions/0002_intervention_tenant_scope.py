"""Add tenant scope to an existing 0.1 interventions table when upgrading.

Revision ID: 0002_tenant_scope
Revises: 0001_core02
"""
import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "0002_tenant_scope"
down_revision = "0001_core02"
branch_labels = None
depends_on = None


def upgrade() -> None:
    inspector = inspect(op.get_bind())
    tables = inspector.get_table_names()
    if "interventions" not in tables:
        return
    columns = {column["name"] for column in inspector.get_columns("interventions")}
    if "institution_id" not in columns:
        op.add_column("interventions", sa.Column("institution_id", sa.String(length=80), nullable=False, server_default="demo-institution"))
        op.create_index("ix_interventions_institution_id", "interventions", ["institution_id"], unique=False)


def downgrade() -> None:
    inspector = inspect(op.get_bind())
    if "interventions" not in inspector.get_table_names():
        return
    columns = {column["name"] for column in inspector.get_columns("interventions")}
    if "institution_id" in columns:
        op.drop_index("ix_interventions_institution_id", table_name="interventions")
        op.drop_column("interventions", "institution_id")
