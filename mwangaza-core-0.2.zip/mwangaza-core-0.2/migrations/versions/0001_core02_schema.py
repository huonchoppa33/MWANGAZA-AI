"""Create the MWANGAZA Core 0.2 institutional data model.

Revision ID: 0001_core02
Revises:
"""
from alembic import op
from app.database import Base

revision = "0001_core02"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    Base.metadata.create_all(bind=op.get_bind())


def downgrade() -> None:
    Base.metadata.drop_all(bind=op.get_bind())
