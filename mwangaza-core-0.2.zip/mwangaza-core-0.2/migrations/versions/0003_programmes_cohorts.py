"""Add tenant-owned programme and cohort registries.

Revision ID: 0003_programmes_cohorts
Revises: 0002_tenant_scope
"""
from alembic import op
from app.database import Base

revision = "0003_programmes_cohorts"
down_revision = "0002_tenant_scope"
branch_labels = None
depends_on = None


def upgrade() -> None:
    Base.metadata.create_all(bind=op.get_bind())


def downgrade() -> None:
    bind = op.get_bind()
    Base.metadata.tables["cohorts"].drop(bind=bind, checkfirst=True)
    Base.metadata.tables["programmes"].drop(bind=bind, checkfirst=True)
