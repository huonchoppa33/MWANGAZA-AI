# MWANGAZA Core 0.2 — Data model

## Tenant and institutional structure

### Institution
- `id`
- `name`
- `is_demo`
- `created_at`

### Department
- `id`
- `institution_id`
- `code`
- `name`

### Programme
- `id` (internal UUID)
- `institution_id`
- `code` (unique within institution)
- `name`
- `department_id`
- `active`

### Cohort
- `id` (internal UUID)
- `institution_id`
- `programme_id`
- `code` (unique within institution)
- `name`
- `enrolled_count`
- `capacity`
- `status`

## Data source and ingestion

### DataSource
- `id`
- `institution_id`
- `name`
- `kind`
- `description`
- `owner_role`
- `enabled`
- `created_at`

### ImportBatch
- `id`
- `institution_id`
- `source_id`
- `file_name`
- `file_sha256`
- `status`
- `total_rows`, `accepted_rows`, `rejected_rows`
- `staged_records_json`, `errors_json`
- `created_by`, `created_at`, `approved_by`, `approved_at`

### AttendanceEvent
- `id`
- `institution_id`
- `event_id` (unique within institution)
- `cohort_id` (cohort business code)
- `session_date`
- `enrolled_count`
- `attendance_count`
- `source_id`
- `batch_id`
- `provenance_json`

## Indicator and decision records

### IndicatorDefinition
- `id`
- `institution_id`
- `code`, `name`, `description`
- `numerator_definition`, `denominator_definition`
- `unit`, `version`, `owner_role`, `active`
- `created_at`

A new meaning or changed calculation creates a new version; prior versions are retained.

### Intervention
- `id`, `institution_id`
- `title`, `cohort_id`
- `management_question`, `hypothesis`, `planned_action`
- `owner_role`, `status`
- `baseline_attendance_rate`, `baseline_session_count`
- `review_date`, `created_at`, `implemented_at`
- `follow_up_attendance_rate`, `change_percentage_points`
- `evaluation_note`, `evidence_references`

### AuditLog
- `id`, `institution_id`, `actor_id`
- `action`, `entity_type`, `entity_id`
- `details_json`, `created_at`

## Knowledge documents

### KnowledgeDocument
- `id`, `institution_id`, `department_id`
- `file_name`, `mime_type`, `sha256`
- `visibility`, `status`, `chunk_count`
- `uploaded_by`, `created_at`

### DocumentChunk
- `id`, `institution_id`, `document_id`
- `chunk_index`, `content`, `page_number`

Only extracted text chunks are stored by this prototype. The original uploaded binary is not retained. A future production lifecycle should include encrypted object storage, document versioning, deletion, retention automation and legal holds where appropriate.

## Design rules

- Personal identity data are not required for the current prototype.
- Programme and cohort IDs are separate from tenant-scoped business codes.
- Event IDs and programme/cohort codes are unique within the institution.
- Every imported event retains its source and batch provenance.
- Indicator definitions are versioned.
- Department-restricted knowledge is filtered during both document listing and retrieval.
- Imported event counts and bundled synthetic demo metrics are reported separately.
