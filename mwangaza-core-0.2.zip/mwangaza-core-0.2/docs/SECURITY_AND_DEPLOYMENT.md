# MWANGAZA Core 0.2 — Security and deployment checklist

## Local development

- Use `APP_ENV=development` and `AUTH_MODE=demo` only on localhost.
- Do not place real participant or confidential institutional data in the demo database.
- Keep `.env` and `frontend/.env.local` out of Git.
- External AI is disabled by default.

## Supabase authentication

- Use `AUTH_MODE=supabase` outside local development.
- Configure `SUPABASE_URL` and an asymmetric Supabase JWKS endpoint where possible.
- Supabase JWT issuer, audience, expiry and signature are checked.
- Populate trusted `app_metadata.institution_id`, `app_metadata.role` and optional `app_metadata.department_id` through a trusted process.
- Do not trust browser-editable `user_metadata` for role or institution membership.
- Provision the institution and its initial departments with `scripts/provision_institution.py` after migrations.
- Provision accounts through an institutional process; the prototype does not offer public self-registration.
- Use trusted `app_metadata.department_id` for department-scoped roles; never accept department assignments from browser-submitted profile fields.
- The API enforces department visibility for programme, cohort, attendance, intervention and knowledge records. Test each role/dept combination before onboarding.

## Database

- Use managed PostgreSQL in production.
- Run `alembic upgrade head` before the API service starts.
- Back up the database before each schema change and test restoration.
- Use least-privilege database credentials and TLS.
- Never expose database credentials or Supabase service-role credentials to the browser.
- The API filters application data by institution ID and, where applicable, department ID; database-level RLS is an additional recommended defence-in-depth control.

## Data import

- Approve data sources and the purpose of each import.
- Stage, validate and preview before approval.
- Review rejected rows and duplicate event IDs.
- Preserve original source files outside the app under institutional retention policy.
- Verify indicator definitions and cohort denominators before using metrics for management reporting.

## Knowledge documents and external AI

- Upload only documents approved for the stated processing purpose.
- Use institution-wide visibility only when appropriate; use department visibility for restricted material.
- Do not upload participant-identifying, confidential or sensitive data without approval and a legal/privacy review.
- External LLM processing requires `OPENAI_API_KEY` and `ALLOW_EXTERNAL_AI=true`; this must follow institutional approval and provider/data-processing review.
- Review document access, deletion and retention requirements before production use.

## Required before a real pilot

- Approved institutional data inventory and source-of-truth map.
- Documented lawful basis, privacy notice and retention policy.
- DPIA where required by risk and applicable law.
- Role and department provisioning process.
- Security testing, rate limits, request-size controls and monitoring.
- Backup and restore exercise.
- Production CORS allowlist and HTTPS.
- Operational support, incident response and data-breach procedure.
- Model and indicator evaluation plan.
- Staff acceptance testing and written pilot sign-off.

## Important limitation

Core 0.2 is an integrated prototype, not a certified production system. Authentication support, tenant filters and audit records are foundations, not a substitute for a full independent security review and deployment approval.
