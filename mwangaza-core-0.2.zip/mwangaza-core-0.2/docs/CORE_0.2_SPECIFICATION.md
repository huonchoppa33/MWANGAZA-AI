# MWANGAZA Core 0.2 — System Requirements Specification

## Product objective

Provide an institution-scoped workspace that connects approved programme and cohort records, staged data imports, indicator definitions, evidence retrieval and intervention tracking. The prototype demonstrates an evidence-to-action workflow without claiming that synthetic metrics represent a real institution.

## Actors and permissions

| Role | Read data | Register sources / programmes / cohorts | Stage imports / upload documents | Approve imports / activate interventions | Read audit |
|---|---:|---:|---:|---:|---:|
| admin | Yes | Yes | Yes | Yes | Yes |
| executive | Yes | Yes | Yes | Yes | Yes |
| programme_manager | Yes | Yes | Yes | No | No |
| analyst | Yes | Yes | Yes | No | Yes |
| staff | Yes | No | No | No | No |
| viewer | Yes | No | No | No | No |

Current local demo mode resolves to a synthetic administrator and is blocked in production. Department-scoped roles (`programme_manager`, `staff`, `viewer`) only see programmes, cohorts, attendance and interventions for the trusted `department_id` claim. A scoped user with no department claim receives no department programme data.

## Functional requirements

| ID | Requirement | Current status |
|---|---|---|
| FR-01 | Authenticate a user and resolve institution, role and optional department claims | Implemented for Supabase JWT configuration; demo fallback is development-only |
| FR-02 | Enforce institution and department scoping on stored institutional records | Implemented in API query paths for programme, cohort, attendance, intervention and knowledge data |
| FR-03 | Register institutions/departments through trusted provisioning and register programmes/cohorts | Implemented; administrator department endpoint added |
| FR-04 | Register data sources | Implemented |
| FR-05 | Stage attendance CSV and validate required columns and row constraints | Implemented |
| FR-06 | Preview accepted/rejected rows before persistence | Implemented |
| FR-07 | Approve staged imports with duplicate protection and provenance | Implemented |
| FR-08 | Version indicator definitions | Implemented |
| FR-09 | Summarise tenant programme, cohort and attendance records | Implemented |
| FR-10 | Generate transparent attendance alerts and experimental forecasts | Implemented; not model-validated |
| FR-11 | Upload approved PDF, DOCX, TXT and Markdown documents | Implemented |
| FR-12 | Retrieve permission-filtered document chunks with citations | Implemented using TF-IDF |
| FR-13 | Optionally use an external LLM with explicit configuration | Implemented as opt-in adapter; requires provider approval |
| FR-14 | Register, approve, activate and evaluate interventions | Implemented; evaluation is descriptive |
| FR-15 | Record audit metadata for sensitive workflows | Partially implemented; not a complete immutable audit system |
| FR-16 | Display management dashboard and data intake workflows | Implemented in Next.js source |

## Data import contract

CSV header names are fixed to `event_id`, `cohort_id`, `session_date`, `enrolled_count`, `attendance_count`. Date values use ISO `YYYY-MM-DD`. Cohort codes must be active in the authenticated institution. Attendance count must be between zero and enrolled count. Enrolled count must not exceed the cohort's registered capacity.

An approved batch records the importer, approver, file hash, source ID, import batch ID and row provenance. Event IDs cannot be duplicated within an institution. Exact files cannot be staged twice against the same source.

## Knowledge ingestion contract

- Maximum file size defaults to 8 MiB.
- Supported file extensions: PDF, DOCX, TXT, MD.
- Extracted text is chunked with overlap.
- Original file bytes are not retained by this prototype.
- Retrieval filters by institution and department visibility.
- External LLM generation is disabled by default.
- Returned sources include document ID, filename, chunk index and relevance score.

## Non-functional requirements

- Tenant isolation at every persistence query and department filtering for department-scoped roles.
- JWT signature, issuer, audience and expiry verification in Supabase mode.
- HTTPS and managed secrets in production.
- PostgreSQL in production; SQLite for local testing only.
- Alembic-controlled schema evolution.
- Explainable rules and explicit limitations on forecasts.
- No automatic eligibility or participant-level risk decisions.
- Documented API and automated test suite.

## Known exclusions

No direct Swahilipot integrations, participant identities, payment or grant allocation, automated decisioning, advanced semantic embeddings, fine-tuning, full causal inference platform, immutable audit service, or production document retention workflow is included in Core 0.2.
