# MWANGAZA Core 0.2 — Architecture

## Purpose and boundary

MWANGAZA is an independent institutional evidence-to-action intelligence prototype. It is not an official Swahilipot application and is not connected to Swahilipot's internal data or systems. Local demo records are synthetic.

## Runtime components

- **Next.js dashboard:** institutional overview, source and CSV intake, knowledge retrieval, intervention workflow.
- **FastAPI API:** institution-scoped endpoints and OpenAPI documentation.
- **Supabase Auth integration:** JWT signature, issuer, audience and expiry verification; trusted app metadata supplies institution and role claims.
- **SQLAlchemy persistence:** SQLite for local development and PostgreSQL via psycopg for managed deployments.
- **Alembic migrations:** versioned schema changes, including the upgrade from the 0.1 intervention table.
- **Institutional data model:** institutions, departments, programmes, cohorts, data sources, import batches, attendance events, indicator versions, documents, chunks, interventions and audit entries.
- **Data ingestion:** preview, validation, approval, idempotent persistence and provenance.
- **Analytics engine:** transparent trend rules and an experimental linear attendance baseline.
- **Knowledge engine:** text extraction, chunking, TF-IDF retrieval and citations. An optional OpenAI Responses API adapter is disabled by default.

## Data flow

1. An authorised user selects or registers a source.
2. A CSV is uploaded to staging and validated against the institution's registered cohort records.
3. The batch is previewed; rejected rows are reported.
4. An authorised executive or administrator approves the batch.
5. Valid attendance events are persisted with source and batch provenance.
6. Tenant-aware analytics compute operational summaries and descriptive signals.
7. Approved documents are extracted into chunks and indexed for institution/department-scoped retrieval.
8. An institutional recommendation can become an intervention proposal.
9. An authorised manager approves implementation and records follow-up observations.
10. Audit metadata preserve the decision and workflow history.

## Tenant boundary

All production data-access queries filter by `institution_id`. Cohort and programme codes are unique within an institution; internal row IDs are separate. Department-restricted documents are visible only to administrators/executives or members of the assigned department. Users without a department claim cannot see department-only documents.

## AI boundary

- Deterministic validation and indicators are not delegated to an LLM.
- Forecasts are experimental descriptive projections, not participant-level recommendations.
- Retrieval outputs cite document and chunk identifiers.
- The LLM adapter receives only the retrieved chunks and is disabled unless explicitly approved and configured.
- The system must abstain when relevant documentary evidence is unavailable.
- Human managers remain responsible for decisions and interventions.

## Production migration

Run Alembic before starting the API. In production, `APP_ENV=production` requires `AUTH_MODE=supabase` and a PostgreSQL database. The application does not create production tables on startup.
