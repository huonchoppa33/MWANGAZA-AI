# MWANGAZA roadmap after Core 0.2

## Core 0.3 — institutional integration and deployment hardening

- Complete institutional discovery with approved Swahilipot stakeholders.
- Confirm the source-of-truth inventory and integration contracts.
- Add API connectors only for systems the institution authorises.
- Implement full document lifecycle, versioning, deletion and retention controls.
- Add database-level PostgreSQL RLS as defence in depth and verify tenant/department claims.
- Add monitoring, rate limits, alerting, backup/restore drills and security review.
- Run the Next.js build and deployment pipeline with pinned dependencies and a lockfile.

## Core 0.4 — validated institutional intelligence

- Obtain a permissioned, minimised historical dataset with approved indicator definitions.
- Establish statistical and process-mining baselines.
- Backtest forecasting models using chronological holdouts.
- Evaluate calibration, stability, subgroup performance and missing-data sensitivity.
- Add scenario simulation only where process and resource data support it.
- Compare C2I decision workflows with the institution's current process.

## Core 0.5 — research and decision intelligence

- Evaluate semantic embeddings against TF-IDF retrieval using a labelled query set.
- Add model/version evaluation and source freshness checks.
- Build a provenance-preserving intervention-to-outcome event graph.
- Run a controlled pilot and assess operational value, staff usability and data quality.
- Conduct a prior-art and IP review before making novelty claims.

## Production pilot gate

A real-data pilot requires institutional approval, a source inventory, lawful basis, privacy review and DPIA where required, approved indicator definitions, access control, audit logging, backup/recovery and security testing.
