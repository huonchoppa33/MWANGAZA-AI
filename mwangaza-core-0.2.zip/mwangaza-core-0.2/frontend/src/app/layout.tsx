import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MWANGAZA | Institutional Intelligence",
  description: "Institutional evidence-to-action intelligence prototype.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
