"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, supabaseConfigured } from "@/lib/supabase";

type Tab = "overview" | "data" | "research" | "interventions";
type JsonRecord = Record<string, unknown>;
type Summary = {
  institution_name: string;
  environment: string;
  demo_only: boolean;
  programme_count: number;
  cohort_count: number;
  attendance_session_count: number;
  overall_attendance_rate: number;
  persistent_attendance_event_count: number;
  source_count: number;
  pending_import_count: number;
  document_count: number;
  intervention_count: number;
  dataset_notice: string;
};
type Insight = {
  insight_id: string;
  category: string;
  severity: "info" | "watch" | "high";
  title: string;
  finding: string;
  recommendation: string;
  limitations: string[];
};
type AttendanceRow = { cohort_id: string; attendance_count: number; enrolled_count: number; session_date: string };
type Cohort = {
  cohort_id: string;
  enrolled_count: number;
  capacity: number;
  name: string;
  session_count: number;
  overall_attendance_rate: number;
  latest_attendance_rate: number | null;
};
type Source = { id: string; name: string; kind: string; owner_role: string };
type Department = { id: string; code: string; name: string };
type Programme = { id: string; code: string; name: string; department_id: string | null };
type Intervention = {
  id: string;
  title: string;
  cohort_id: string;
  status: string;
  baseline_attendance_rate: number;
  review_date: string;
  evaluation_note?: string | null;
};
type DocumentItem = { id: string; file_name: string; visibility: string; chunk_count: number; created_at: string };
type ResearchResult = {
  answer: string;
  answer_mode: string;
  grounded: boolean;
  sources: { citation: string; document_id: string; file_name: string; chunk_index: number; snippet: string; relevance: number }[];
  limitations: string[];
};

const API_BASE = (process.env.NEXT_PUBLIC_API_BASE_URL || "http://127.0.0.1:8000").replace(/\/$/, "");
const navigation: { id: Tab; title: string; icon: string }[] = [
  { id: "overview", title: "Overview", icon: "◫" },
  { id: "data", title: "Data intake", icon: "⇧" },
  { id: "research", title: "Knowledge AI", icon: "✳" },
  { id: "interventions", title: "Interventions", icon: "◎" },
];

async function request<T>(path: string, token: string | null, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers || {});
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (!(init.body instanceof FormData) && init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, { ...init, headers, cache: "no-store" });
  } catch {
    throw new Error(`Cannot reach the MWANGAZA API at ${API_BASE}. Start the Python API and check NEXT_PUBLIC_API_BASE_URL.`);
  }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = body?.detail;
    const message = typeof detail === "string" ? detail : detail ? JSON.stringify(detail) : `Request failed (${response.status})`;
    throw new Error(message);
  }
  return body as T;
}

function pct(value: number | null | undefined) {
  return value == null || !Number.isFinite(value) ? "—" : `${(value * 100).toFixed(1)}%`;
}
function shortDate(value: string) {
  return new Intl.DateTimeFormat("en-KE", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(value));
}

export default function Home() {
  const [tab, setTab] = useState<Tab>("overview");
  const [session, setSession] = useState<Session | null>(null);
  const [identity, setIdentity] = useState<JsonRecord | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [cohorts, setCohorts] = useState<Cohort[]>([]);
  const [attendanceRows, setAttendanceRows] = useState<AttendanceRow[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);
  const [sources, setSources] = useState<Source[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [sourceName, setSourceName] = useState("");
  const [sourceKind, setSourceKind] = useState("file");
  const [sourceDescription, setSourceDescription] = useState("");
  const [programmeCode, setProgrammeCode] = useState("NEW_PROGRAMME");
  const [programmeName, setProgrammeName] = useState("");
  const [programmeDepartment, setProgrammeDepartment] = useState("");
  const [cohortCode, setCohortCode] = useState("NEW_COHORT");
  const [cohortName, setCohortName] = useState("");
  const [cohortProgrammeId, setCohortProgrammeId] = useState("");
  const [cohortEnrolled, setCohortEnrolled] = useState("20");
  const [cohortCapacity, setCohortCapacity] = useState("25");
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [selectedSource, setSelectedSource] = useState("");
  const [previewBatch, setPreviewBatch] = useState<JsonRecord | null>(null);
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [documentVisibility, setDocumentVisibility] = useState("institution");
  const [documentDepartment, setDocumentDepartment] = useState("");
  const [question, setQuestion] = useState("");
  const [researchResult, setResearchResult] = useState<ResearchResult | null>(null);
  const [interventionTitle, setInterventionTitle] = useState("Review cohort session timing");
  const [interventionCohort, setInterventionCohort] = useState("COH-TECH-A");
  const [managementQuestion, setManagementQuestion] = useState("Could session timing contribute to lower recent attendance?");
  const [hypothesis, setHypothesis] = useState("A revised session time may improve attendance if scheduling is a material barrier.");
  const [plannedAction, setPlannedAction] = useState("Test a manager-approved timetable adjustment for the next three sessions.");
  const [ownerRole, setOwnerRole] = useState("Programme Manager");
  const [reviewDate, setReviewDate] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 30); return d.toISOString().slice(0, 10); });
  const [evaluationId, setEvaluationId] = useState("");
  const [followUpCounts, setFollowUpCounts] = useState("25,26,27");
  const [followUpEvidence, setFollowUpEvidence] = useState("");

  const token = session?.access_token || null;
  const authConfigured = supabaseConfigured;
  const role = typeof identity?.role === "string" ? identity.role : "";
  const fullInstitutionRoles = ["admin", "executive", "analyst"];
  const canManage = Boolean(identity?.demo_mode) || ["admin", "executive", "programme_manager", "analyst"].includes(role);
  const canApprove = Boolean(identity?.demo_mode) || ["admin", "executive"].includes(role);
  const canInstitutionScope = Boolean(identity?.demo_mode) || fullInstitutionRoles.includes(role);

  const refreshData = useCallback(async (accessToken: string | null) => {
    setLoading(true);
    setError("");
    try {
      const [who, dashboard] = await Promise.all([
        request<JsonRecord>("/api/v1/identity", accessToken),
        request<Summary>("/api/v1/dashboard/summary", accessToken),
      ]);
      const [cohortRows, programmeRows, eventRows, insightRows, sourceRows, departmentRows, documentRows, interventionRows] = await Promise.all([
        request<Cohort[]>("/api/v1/cohorts", accessToken),
        request<Programme[]>("/api/v1/programmes", accessToken),
        who.demo_mode
          ? request<JsonRecord>("/api/v1/demo/dataset", accessToken).then((data) => (data.attendance_sessions || []) as AttendanceRow[])
          : request<AttendanceRow[]>("/api/v1/attendance/events", accessToken),
        request<Insight[]>("/api/v1/insights", accessToken),
        request<Source[]>("/api/v1/sources", accessToken),
        request<Department[]>("/api/v1/departments", accessToken),
        request<DocumentItem[]>("/api/v1/knowledge/documents", accessToken),
        request<Intervention[]>("/api/v1/interventions", accessToken),
      ]);
      setIdentity(who);
      setSummary(dashboard);
      setCohorts(cohortRows);
      setProgrammes(programmeRows);
      setAttendanceRows(eventRows);
      setInsights(insightRows);
      setSources(sourceRows);
      setDepartments(departmentRows);
      setDocuments(documentRows);
      setInterventions(interventionRows);
      if (sourceRows.length) setSelectedSource((current) => current || sourceRows[0].id);
      if (programmeRows.length) setCohortProgrammeId((current) => current || programmeRows[0].id);
      const institutionWide = Boolean(who.demo_mode) || ["admin", "executive", "analyst"].includes(String(who.role));
      const assignedDepartment = typeof who.department_id === "string" ? who.department_id : "";
      if (!institutionWide && assignedDepartment) {
        setProgrammeDepartment(assignedDepartment);
        setDocumentVisibility("department");
        setDocumentDepartment(assignedDepartment);
      } else if (departmentRows.length) {
        setProgrammeDepartment((current) => current || departmentRows[0].id);
      }
      if (cohortRows.length) {
        setInterventionCohort((current) => cohortRows.some((row) => row.cohort_id === current) ? current : cohortRows[0].cohort_id);
      }
      if (who.demo_mode) setNotice("Local development mode · all bundled programme metrics are synthetic.");
      else setNotice("Authenticated institutional workspace · access is restricted by your role and institution.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load dashboard data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (supabase) {
      supabase.auth.getSession().then(({ data }) => setSession(data.session));
      const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => setSession(newSession));
      return () => listener.subscription.unsubscribe();
    }
  }, []);

  useEffect(() => {
    if (!authConfigured || session) void refreshData(token);
  }, [authConfigured, session, token, refreshData]);

  const chart = useMemo(() => {
    const first = cohorts[0];
    const second = cohorts[1];
    const toLine = (cohortId?: string) => {
      if (!cohortId) return "";
      const rows = attendanceRows
        .filter((row) => row.cohort_id === cohortId)
        .sort((a, b) => a.session_date.localeCompare(b.session_date))
        .slice(-10);
      return rows.map((row, index) => {
        const x = 34 + index * 55;
        const rate = row.enrolled_count ? row.attendance_count / row.enrolled_count : 0;
        const y = 180 - Math.max(0, Math.min(1, (rate - 0.45) / 0.45)) * 150;
        return `${x},${y}`;
      }).join(" ");
    };
    return { primary: toLine(first?.cohort_id), secondary: toLine(second?.cohort_id), primaryName: first?.name || "Cohort 1", secondaryName: second?.name || "Cohort 2" };
  }, [attendanceRows, cohorts]);

  async function handleLogin(event: FormEvent) {
    event.preventDefault();
    if (!supabase) return;
    setBusy(true); setLoginError("");
    const { error: authError } = await supabase.auth.signInWithPassword({ email: loginEmail, password: loginPassword });
    if (authError) setLoginError(authError.message);
    setBusy(false);
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setSession(null); setIdentity(null);
  }

  async function createProgramme(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const created = await request<Programme>("/api/v1/programmes", token, { method: "POST", body: JSON.stringify({ code: programmeCode.trim().toUpperCase(), name: programmeName, department_id: programmeDepartment || null }) });
      setProgrammeName(""); setProgrammeCode("NEW_PROGRAMME"); setCohortProgrammeId(created.id);
      setNotice("Programme registered. You can now add cohorts under it."); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not register programme."); }
    finally { setBusy(false); }
  }

  async function createCohort(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      await request<Cohort>("/api/v1/cohorts", token, { method: "POST", body: JSON.stringify({ cohort_id: cohortCode.trim().toUpperCase(), programme_id: cohortProgrammeId, name: cohortName, enrolled_count: Number(cohortEnrolled), capacity: Number(cohortCapacity) }) });
      setCohortName(""); setCohortCode("NEW_COHORT");
      setNotice("Cohort registered. Its code can now be used in attendance CSV imports."); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not register cohort."); }
    finally { setBusy(false); }
  }

  async function createSource(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const created = await request<Source>("/api/v1/sources", token, { method: "POST", body: JSON.stringify({ name: sourceName, kind: sourceKind, description: sourceDescription, owner_role: "Data Steward" }) });
      setSourceName(""); setSourceDescription(""); setSelectedSource(created.id);
      setNotice("Source registered successfully."); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not create source."); }
    finally { setBusy(false); }
  }

  async function previewCsv(event: FormEvent) {
    event.preventDefault();
    if (!csvFile || !selectedSource) return;
    setBusy(true); setError(""); setNotice(""); setPreviewBatch(null);
    const form = new FormData(); form.append("file", csvFile); form.append("source_id", selectedSource);
    try {
      const batch = await request<JsonRecord>("/api/v1/imports/preview", token, { method: "POST", body: form });
      const detail = await request<JsonRecord>(`/api/v1/imports/${String(batch.id)}`, token);
      setPreviewBatch(detail); setNotice("Import staged. Review the counts and rejected rows before approval."); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not preview the CSV."); }
    finally { setBusy(false); }
  }

  async function approveImport() {
    const id = String(previewBatch?.id || ""); if (!id) return;
    setBusy(true); setError("");
    try {
      const result = await request<JsonRecord>(`/api/v1/imports/${id}/approve`, token, { method: "POST" });
      setNotice(`Import approved · ${result.inserted_count} attendance events stored · ${result.duplicate_events_skipped} duplicate events skipped.`);
      setPreviewBatch({ ...previewBatch, status: result.status }); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not approve import."); }
    finally { setBusy(false); }
  }

  async function uploadDocument(event: FormEvent) {
    event.preventDefault(); if (!documentFile) return;
    setBusy(true); setError(""); setNotice("");
    const form = new FormData(); form.append("file", documentFile); form.append("visibility", documentVisibility); if (documentVisibility === "department") form.append("department_id", documentDepartment);
    try {
      const result = await request<JsonRecord>("/api/v1/knowledge/documents", token, { method: "POST", body: form });
      setNotice(`Document indexed: ${result.file_name} · ${result.chunk_count} searchable chunks.`); setDocumentFile(null); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Document upload failed."); }
    finally { setBusy(false); }
  }

  async function askResearch(event: FormEvent) {
    event.preventDefault(); if (!question.trim()) return;
    setBusy(true); setError(""); setResearchResult(null);
    try {
      const result = await request<ResearchResult>("/api/v1/knowledge/query", token, { method: "POST", body: JSON.stringify({ question, top_k: 5 }) });
      setResearchResult(result);
    } catch (err) { setError(err instanceof Error ? err.message : "Research query failed."); }
    finally { setBusy(false); }
  }

  async function createIntervention(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      await request<Intervention>("/api/v1/interventions", token, { method: "POST", body: JSON.stringify({ title: interventionTitle, cohort_id: interventionCohort, management_question: managementQuestion, hypothesis, planned_action: plannedAction, owner_role: ownerRole, review_date: reviewDate }) });
      setNotice("Proposed intervention recorded. An authorised executive must approve implementation."); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not record intervention."); }
    finally { setBusy(false); }
  }

  async function implementIntervention(id: string) {
    setBusy(true); setError("");
    try { await request<Intervention>(`/api/v1/interventions/${id}/implement`, token, { method: "POST" }); setNotice("Intervention marked active."); await refreshData(token); }
    catch (err) { setError(err instanceof Error ? err.message : "Could not implement intervention."); }
    finally { setBusy(false); }
  }

  async function evaluateIntervention(event: FormEvent) {
    event.preventDefault(); if (!evaluationId) return;
    const counts = followUpCounts.split(",").map((item) => Number(item.trim()));
    if (!counts.length || counts.length > 30 || counts.some((n) => !Number.isInteger(n) || n < 0)) { setError("Enter 1–30 comma-separated whole-number attendance counts."); return; }
    const selectedIntervention = interventions.find((item) => item.id === evaluationId);
    const selectedCohort = selectedIntervention ? cohorts.find((item) => item.cohort_id === selectedIntervention.cohort_id) : undefined;
    if (!selectedCohort) { setError("The intervention's registered cohort could not be found. Refresh the workspace and try again."); return; }
    if (counts.some((count) => count > selectedCohort.enrolled_count)) { setError(`Each attendance count must be no greater than the cohort's ${selectedCohort.enrolled_count} enrolled participants.`); return; }
    const evidenceReferences = followUpEvidence.split(",").map((item) => item.trim()).filter(Boolean).slice(0, 30);
    setBusy(true); setError("");
    try {
      await request<Intervention>(`/api/v1/interventions/${evaluationId}/evaluate`, token, { method: "POST", body: JSON.stringify({ follow_up_attendance_counts: counts, enrolled_count: selectedCohort.enrolled_count, evidence_references: evidenceReferences }) });
      setNotice("Follow-up observations recorded. This comparison is descriptive and does not establish causation."); setEvaluationId(""); setFollowUpEvidence(""); await refreshData(token);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not evaluate intervention."); }
    finally { setBusy(false); }
  }

  if (authConfigured && !session) {
    return <main className="login"><div className="login-card"><div className="brand"><div className="brand-mark">M</div><div><div className="brand-name">MWANGAZA</div><div className="brand-sub">Institutional intelligence</div></div></div><h1>Sign in to your workspace</h1><p>Use the account provisioned by your institution. Access is governed by trusted Supabase application metadata.</p><form onSubmit={handleLogin}><div className="field"><label>Email address</label><input type="email" required value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} /></div><div className="field"><label>Password</label><input type="password" required value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} /></div>{loginError && <div className="error">{loginError}</div>}<button className="button" disabled={busy} style={{ width: "100%", marginTop: 12 }}>{busy ? "Signing in…" : "Sign in securely"}</button></form><p className="footer-note">No self-registration is enabled in this institutional prototype.</p></div></main>;
  }

  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">M</div><div><div className="brand-name">MWANGAZA</div><div className="brand-sub">Institutional intelligence</div></div></div>
      <div><div className="nav-label">Workspace</div><nav className="nav">{navigation.map((item) => <button key={item.id} className={tab === item.id ? "active" : ""} onClick={() => setTab(item.id)}><span className="nav-icon">{item.icon}</span>{item.title}</button>)}</nav></div>
      <div className="sidebar-bottom"><div className="mode-card"><span className="mode-pill"><i className="mode-dot" />{identity?.demo_mode ? "Local demo" : "Connected"}</span><p>{String(identity?.institution_id || "Institution")}</p><p>Role: {String(identity?.role || "loading")}</p></div><button className="button ghost" style={{ width: "100%", marginTop: 12 }} onClick={signOut}>Sign out</button></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="eyebrow">Institutional intelligence / workspace</div><div className="top-title">{summary?.institution_name || "MWANGAZA Core"}</div></div><div className="top-actions"><span className="status">API connected</span><div className="avatar">{String(identity?.role || "M").slice(0, 1).toUpperCase()}</div></div></header>
      <nav className="mobile-head">{navigation.map((item) => <button key={item.id} className={tab === item.id ? "active" : ""} onClick={() => setTab(item.id)}>{item.icon} {item.title}</button>)}</nav>
      <div className="content">
        {error && <div className="error" style={{ marginBottom: 14 }}>{error}</div>}
        {notice && <div className="success" style={{ marginBottom: 14 }}>{notice}</div>}
        {loading && <div className="notice" style={{ marginBottom: 14 }}>Refreshing institution-scoped workspace data…</div>}

        <section className={`section ${tab === "overview" ? "active" : ""}`}>
          <div className="page-heading"><div><div className="label">Control room / 01</div><h1>Institutional overview</h1><p>One operational view of programmes, evidence, data and interventions.</p></div><button className="button secondary" onClick={() => refreshData(token)}>↻ Refresh data</button></div>
          {summary && <div className="notice" style={{ marginBottom: 15 }}>{summary.dataset_notice}</div>}
          <div className="grid stats">
            <div className="card"><div className="stat-top">Programmes <span className="stat-icon">▦</span></div><div className="stat-value">{summary?.programme_count ?? "—"}</div><div className="stat-foot">{summary?.demo_only ? "Illustrative programme categories" : "Registered active programmes"}</div></div>
            <div className="card"><div className="stat-top">Cohorts <span className="stat-icon">◉</span></div><div className="stat-value">{summary?.cohort_count ?? "—"}</div><div className="stat-foot">{summary?.demo_only ? "Synthetic demonstration cohorts" : "Registered institutional cohorts"}</div></div>
            <div className="card"><div className="stat-top">{summary?.demo_only ? "Demo attendance" : "Attendance rate"} <span className="stat-icon">⌁</span></div><div className="stat-value">{summary?.attendance_session_count ? pct(summary.overall_attendance_rate) : "—"}</div><div className={`stat-foot ${summary?.demo_only ? "demo" : ""}`}>{summary?.demo_only ? "Synthetic metric · not a live institutional KPI" : summary?.attendance_session_count ? "Based on approved attendance events in your authorised scope" : "No approved attendance events available yet"}</div></div>
            <div className="card"><div className="stat-top">Imported events <span className="stat-icon">⇧</span></div><div className="stat-value">{summary?.persistent_attendance_event_count ?? "—"}</div><div className="stat-foot">Approved events stored in this workspace</div></div>
          </div>
          <div className="grid overview-grid">
            <div className="card"><div className="card-head"><div><div className="card-title">Attendance pattern</div><div className="card-subtitle">{summary?.demo_only ? "Synthetic cohort trend" : "Imported institutional events"} · percentage of enrolled participants</div></div><span className="pill">10 sessions</span></div><div className="chart-wrap">{attendanceRows.length ? <svg viewBox="0 0 560 220" role="img" aria-label="Attendance trend chart for the first two visible cohorts"><line className="chart-grid-line" x1="28" y1="30" x2="540" y2="30"/><line className="chart-grid-line" x1="28" y1="80" x2="540" y2="80"/><line className="chart-grid-line" x1="28" y1="130" x2="540" y2="130"/><line className="chart-grid-line" x1="28" y1="180" x2="540" y2="180"/><text className="chart-text" x="2" y="33">90%</text><text className="chart-text" x="2" y="83">75%</text><text className="chart-text" x="2" y="133">60%</text><text className="chart-text" x="2" y="183">45%</text><polyline points={chart.primary} fill="none" stroke="#67e1c0" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/><polyline points={chart.secondary} fill="none" stroke="#8ab9ff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/><text className="chart-text" x="30" y="207">Earlier sessions</text><text className="chart-text" x="475" y="207">Latest sessions</text></svg> : <div className="empty">No attendance events are available for the selected workspace scope yet.</div>}</div><div className="legend"><span>{chart.primaryName}</span>{chart.secondary && <span>{chart.secondaryName}</span>}</div></div>
            <div className="card"><div className="card-head"><div><div className="card-title">Evidence-led alerts</div><div className="card-subtitle">Rule-based findings · require human review</div></div><span className="pill">{insights.length} signals</span></div><div className="insights">{insights.slice(0, 4).map((item) => <div className="insight" key={item.insight_id}><div className="insight-top"><span className={`tag ${item.severity}`}>{item.severity}</span><span className="tag">{item.category}</span></div><h3>{item.title}</h3><p>{item.finding}</p></div>)}{!insights.length && <div className="empty">No insight signals returned.</div>}</div></div>
          </div>
          <div className="card"><div className="card-head"><div><div className="card-title">Cohort performance</div><div className="card-subtitle">{summary?.demo_only ? "Synthetic data used to validate the dashboard and analytics pipeline" : "Registered cohorts and approved attendance records in your authorised scope"}</div></div><span className="pill">{summary?.demo_only ? "DEMO DATA" : "INSTITUTION DATA"}</span></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Cohort</th><th>Sessions</th><th>Overall attendance</th><th>Latest attendance</th><th>Data status</th></tr></thead><tbody>{cohorts.map((cohort) => <tr key={cohort.cohort_id}><td><strong>{cohort.name}</strong><div className="muted">{cohort.cohort_id}</div></td><td>{cohort.session_count}</td><td><div className="rate">{pct(cohort.overall_attendance_rate)}<span className="bar"><i style={{ width: `${cohort.overall_attendance_rate * 100}%` }}/></span></div></td><td>{pct(cohort.latest_attendance_rate)}</td><td><span className={`tag ${summary?.demo_only ? "watch" : cohort.session_count > 0 ? "info" : ""}`}>{summary?.demo_only ? "Synthetic" : cohort.session_count > 0 ? "Imported" : "No events"}</span></td></tr>)}</tbody></table></div></div>
        </section>

        <section className={`section ${tab === "data" ? "active" : ""}`}>
          <div className="page-heading"><div><div className="label">Data operations / 02</div><h1>Data intake & governance</h1><p>Register sources, stage CSV files, inspect validation and approve imports.</p></div><span className="pill">TENANT-SCOPED</span></div>
          {canManage && <div className="content-grid">
            <div className="card"><div className="card-title">Register a data source</div><div className="card-subtitle">Create a source record before staging its files.</div><form onSubmit={createSource}><div className="field"><label>Source name</label><input required minLength={3} value={sourceName} onChange={(e) => setSourceName(e.target.value)} placeholder="e.g. Programme attendance export"/></div><div className="field"><label>Source type</label><select value={sourceKind} onChange={(e) => setSourceKind(e.target.value)}><option value="file">File / spreadsheet</option><option value="api">API</option><option value="database">Database</option><option value="manual">Manual entry</option><option value="synthetic">Synthetic data</option></select></div><div className="field"><label>Description</label><textarea value={sourceDescription} onChange={(e) => setSourceDescription(e.target.value)} placeholder="Owner, purpose, refresh frequency…"/></div><button className="button" disabled={busy}>Register source</button></form></div>
            <div className="card"><div className="card-title">Stage attendance CSV</div><div className="card-subtitle">No data is committed until an authorised approver confirms the preview.</div><form onSubmit={previewCsv}><div className="field"><label>Registered source</label><select required value={selectedSource} onChange={(e) => setSelectedSource(e.target.value)}><option value="">Choose a source</option>{sources.map((source) => <option key={source.id} value={source.id}>{source.name}</option>)}</select></div><div className="file-drop">Select a UTF-8 CSV file<input type="file" accept=".csv,text/csv" onChange={(e) => setCsvFile(e.target.files?.[0] || null)}/>{csvFile && <div style={{ marginTop: 8, color: "#a6f1dc" }}>{csvFile.name}</div>}</div><p className="footer-note">Required columns: event_id, cohort_id, session_date, enrolled_count, attendance_count.</p><button className="button" disabled={busy || !csvFile || !selectedSource} style={{ marginTop: 10 }}>Validate & stage CSV</button></form></div>
          </div>}
          {canManage ? <div className="card" style={{ marginTop: 14 }}><div className="card-head"><div><div className="card-title">Programme and cohort registry</div><div className="card-subtitle">Create the programme structure before importing session-level attendance records.</div></div><span className="pill">{programmes.length} programmes · {cohorts.length} cohorts</span></div><div className="content-grid"><form onSubmit={createProgramme}><div className="field"><label>Programme code</label><input required pattern="[A-Za-z0-9_-]+" value={programmeCode} onChange={(e) => setProgrammeCode(e.target.value)} /></div><div className="field"><label>Programme name</label><input required minLength={3} value={programmeName} onChange={(e) => setProgrammeName(e.target.value)} placeholder="e.g. Digital Skills Programme" /></div><div className="field"><label>Department</label><select value={programmeDepartment} onChange={(e) => setProgrammeDepartment(e.target.value)}>{canInstitutionScope && <option value="">No department assigned</option>}{departments.map((dept) => <option key={dept.id} value={dept.id}>{dept.name}</option>)}</select></div><button className="button secondary" disabled={busy}>Create programme</button></form><form onSubmit={createCohort}><div className="field"><label>Cohort code</label><input required pattern="[A-Za-z0-9_-]+" value={cohortCode} onChange={(e) => setCohortCode(e.target.value)} /></div><div className="field"><label>Cohort name</label><input required minLength={3} value={cohortName} onChange={(e) => setCohortName(e.target.value)} placeholder="e.g. November 2026 cohort" /></div><div className="field"><label>Parent programme</label><select required value={cohortProgrammeId} onChange={(e) => setCohortProgrammeId(e.target.value)}><option value="">Select programme</option>{programmes.map((programme) => <option key={programme.id} value={programme.id}>{programme.name}</option>)}</select></div><div className="grid" style={{ gridTemplateColumns: "1fr 1fr", gap: 10 }}><div className="field"><label>Enrolled</label><input type="number" min="1" required value={cohortEnrolled} onChange={(e) => setCohortEnrolled(e.target.value)} /></div><div className="field"><label>Capacity</label><input type="number" min="1" required value={cohortCapacity} onChange={(e) => setCohortCapacity(e.target.value)} /></div></div><button className="button secondary" disabled={busy || !cohortProgrammeId}>Create cohort</button></form></div></div>
          : <div className="notice">Your role has read-only access to programme and cohort records.</div>}
          {previewBatch && <div className="card" style={{ marginTop: 14 }}><div className="card-head"><div><div className="card-title">Import preview</div><div className="card-subtitle">{String(previewBatch.file_name)} · {String(previewBatch.id)}</div></div><span className={`tag ${previewBatch.status === "pending" ? "watch" : "info"}`}>{String(previewBatch.status)}</span></div><div className="grid stats"><div><div className="stat-foot">Total rows</div><div className="stat-value">{String(previewBatch.total_rows)}</div></div><div><div className="stat-foot">Accepted</div><div className="stat-value">{String(previewBatch.accepted_rows)}</div></div><div><div className="stat-foot">Rejected</div><div className="stat-value">{String(previewBatch.rejected_rows)}</div></div></div>{Array.isArray(previewBatch.errors) && previewBatch.errors.length > 0 && <div className="error" style={{ marginBottom: 12 }}><strong>Rejected rows</strong><pre style={{ whiteSpace: "pre-wrap", marginBottom: 0 }}>{JSON.stringify(previewBatch.errors, null, 2)}</pre></div>}{previewBatch.status === "pending" && (canApprove ? <button className="button" disabled={busy || Number(previewBatch.accepted_rows) === 0} onClick={approveImport}>Approve accepted rows</button> : <div className="notice">Import approval is restricted to executive and administrator roles. Ask an authorised approver to review this batch.</div>)}</div>}
          <div className="card" style={{ marginTop: 14 }}><div className="card-head"><div><div className="card-title">Registered sources</div><div className="card-subtitle">Sources are scoped to the authenticated institution.</div></div><span className="pill">{sources.length} sources</span></div><div className="source-list">{sources.map((source) => <div className="source-row" key={source.id}><div><div className="source-name">{source.name}</div><div className="source-meta">{source.kind} · owner: {source.owner_role}</div></div><span className="tag info">enabled</span></div>)}{!sources.length && <div className="empty">No sources registered yet.</div>}</div></div>
        </section>

        <section className={`section ${tab === "research" ? "active" : ""}`}>
          <div className="page-heading"><div><div className="label">Knowledge layer / 03</div><h1>Institutional knowledge AI</h1><p>Upload approved documents and retrieve evidence with source references.</p></div><span className="pill">RAG · SOURCE-GROUNDED</span></div>
          <div className="content-grid">
            {canManage && <div className="card"><div className="card-title">Add a knowledge document</div><div className="card-subtitle">Supported: PDF, DOCX, TXT and Markdown. Files are stored inside the configured database.</div><form onSubmit={uploadDocument}><div className="file-drop">Select approved document<input type="file" accept=".pdf,.docx,.txt,.md" onChange={(e) => setDocumentFile(e.target.files?.[0] || null)}/>{documentFile && <div style={{ marginTop: 8, color: "#a6f1dc" }}>{documentFile.name}</div>}</div><div className="field"><label>Visibility</label><select value={documentVisibility} onChange={(e) => setDocumentVisibility(e.target.value)}>{canInstitutionScope && <option value="institution">Institution-wide</option>}<option value="department">Department-only</option></select></div>{documentVisibility === "department" && <div className="field"><label>Department</label><select required value={documentDepartment} onChange={(e) => setDocumentDepartment(e.target.value)}><option value="">Choose department</option>{departments.map((dept) => <option key={dept.id} value={dept.id}>{dept.name}</option>)}</select></div>}<button className="button" disabled={busy || !documentFile}>Upload & index</button></form><div className="notice" style={{ marginTop: 13 }}>Do not upload personal, confidential or sensitive documents unless the institution has approved the purpose, access rules and data-processing arrangements.</div></div>}
            <div className="card"><div className="card-title">Ask the knowledge base</div><div className="card-subtitle">Answers are restricted to documents your role may access.</div><form onSubmit={askResearch}><div className="field"><label>Your research question</label><textarea required minLength={5} value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="What evidence should programme managers review before changing a timetable?"/></div><button className="button" disabled={busy || question.trim().length < 5}>{busy ? "Searching evidence…" : "Search & answer"}</button></form>{researchResult && <div style={{ marginTop: 15 }}><div className="row-between" style={{ marginBottom: 8 }}><span className={`tag ${researchResult.grounded ? "info" : "watch"}`}>{researchResult.grounded ? "Evidence found" : "No evidence found"}</span><span className="tag">{researchResult.answer_mode}</span></div><div className="answer">{researchResult.answer}</div>{researchResult.sources.map((source) => <div className="source-cite" key={`${source.document_id}-${source.chunk_index}`}><div className="row-between"><strong>[{source.citation}] {source.file_name}</strong><span className="tag">score {source.relevance.toFixed(3)}</span></div><p>{source.snippet}</p></div>)}</div>}</div>
          </div>
          <div className="card" style={{ marginTop: 14 }}><div className="card-head"><div><div className="card-title">Approved knowledge documents</div><div className="card-subtitle">Documents are indexed as text chunks for permission-aware retrieval.</div></div><span className="pill">{documents.length} documents</span></div><div className="source-list">{documents.map((doc) => <div className="source-row" key={doc.id}><div><div className="source-name">{doc.file_name}</div><div className="source-meta">{doc.visibility} · {doc.chunk_count} chunks · {shortDate(doc.created_at)}</div></div><span className="tag info">indexed</span></div>)}{!documents.length && <div className="empty">No knowledge documents have been indexed.</div>}</div></div>
        </section>

        <section className={`section ${tab === "interventions" ? "active" : ""}`}>
          <div className="page-heading"><div><div className="label">Evidence-to-action / 04</div><h1>Intervention register</h1><p>Document a management hypothesis, approval, action and follow-up result.</p></div><span className="pill">C2I WORKFLOW</span></div>
          <div className="content-grid">
            {canManage && <div className="card"><div className="card-title">Propose an intervention</div><div className="card-subtitle">{summary?.demo_only ? "This workflow uses synthetic cohorts and must not be treated as a live Swahilipot record." : "This workflow uses your institution's registered cohorts and imported attendance history."}</div><form onSubmit={createIntervention}><div className="field"><label>Intervention title</label><input required minLength={5} value={interventionTitle} onChange={(e) => setInterventionTitle(e.target.value)}/></div><div className="field"><label>Registered cohort</label><select value={interventionCohort} onChange={(e) => setInterventionCohort(e.target.value)}>{cohorts.map((c) => <option key={c.cohort_id} value={c.cohort_id}>{c.name}</option>)}</select></div><div className="field"><label>Management question</label><textarea required minLength={10} value={managementQuestion} onChange={(e) => setManagementQuestion(e.target.value)}/></div><div className="field"><label>Hypothesis</label><textarea required minLength={10} value={hypothesis} onChange={(e) => setHypothesis(e.target.value)}/></div><div className="field"><label>Planned action</label><textarea required minLength={10} value={plannedAction} onChange={(e) => setPlannedAction(e.target.value)}/></div><div className="field"><label>Responsible role</label><input required value={ownerRole} onChange={(e) => setOwnerRole(e.target.value)}/></div><div className="field"><label>Review date</label><input type="date" required value={reviewDate} onChange={(e) => setReviewDate(e.target.value)}/></div><button className="button" disabled={busy}>Record proposal</button></form></div>}
            {canApprove && <div className="card"><div className="card-title">Follow-up evaluation</div><div className="card-subtitle">Enter observed attendance counts after an intervention has been implemented.</div><form onSubmit={evaluateIntervention}><div className="field"><label>Active intervention</label><select required value={evaluationId} onChange={(e) => setEvaluationId(e.target.value)}><option value="">Select an active intervention</option>{interventions.filter((i) => i.status === "active").map((i) => <option key={i.id} value={i.id}>{i.title}</option>)}</select></div><div className="field"><label>Follow-up attendance counts (comma-separated)</label><input value={followUpCounts} onChange={(e) => setFollowUpCounts(e.target.value)} placeholder="25,26,27"/></div><div className="field"><label>Evidence references (comma-separated, optional)</label><input value={followUpEvidence} onChange={(e) => setFollowUpEvidence(e.target.value)} placeholder="Report ID, survey ID, meeting record…"/></div><div className="notice">The denominator is taken from the registered cohort. The system records a descriptive difference, not causal proof. Attach an approved evidence reference where available.</div><button className="button secondary" style={{ marginTop: 12 }} disabled={busy || !evaluationId}>Record follow-up observations</button></form></div>}
          </div>
          <div className="card" style={{ marginTop: 14 }}><div className="card-head"><div><div className="card-title">Decision and intervention history</div><div className="card-subtitle">Proposed changes remain separate from approved and evaluated interventions.</div></div><span className="pill">{interventions.length} records</span></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Intervention</th><th>Cohort</th><th>Baseline</th><th>Review date</th><th>Status</th><th>Action</th></tr></thead><tbody>{interventions.map((item) => <tr key={item.id}><td><strong>{item.title}</strong><div className="muted">{item.id.slice(0, 8)}</div></td><td>{item.cohort_id}</td><td>{pct(item.baseline_attendance_rate)}</td><td>{shortDate(item.review_date)}</td><td><span className={`tag ${item.status === "evaluated" ? "info" : item.status === "active" ? "watch" : ""}`}>{item.status}</span></td><td>{item.status === "proposed" ? (canApprove ? <button className="button secondary" disabled={busy} onClick={() => implementIntervention(item.id)}>Approve & activate</button> : <span className="muted">Awaiting authorised approval</span>) : item.status === "active" ? <span className="muted">Ready for evaluation</span> : <span className="muted">Recorded</span>}</td></tr>)}</tbody></table>{!interventions.length && <div className="empty">No interventions recorded yet.</div>}</div></div>
        </section>
        <div className="footer-note">MWANGAZA Core 0.2 · independent prototype · not an official Swahilipot system · synthetic demonstration metrics must not be reported as real institutional outcomes.</div>
      </div>
    </main>
  </div>;
}
