# MWANGAZA Dashboard

Next.js 15.5.29 / React 19 management dashboard for MWANGAZA Core 0.2.

## Local run

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`. The FastAPI service must be running at `NEXT_PUBLIC_API_BASE_URL` (default `http://127.0.0.1:8000`).

If both `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` are set, the app shows a Supabase email/password sign-in screen. Otherwise it uses local development demo mode. The backend still enforces the actual role and institution claims in the access token.

## Build

```bash
npm run build
npm run start
```

Do not expose a Supabase service-role key or database password through `NEXT_PUBLIC_*` variables.
