from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from app.config import settings
from app.database import (
    Base,
    Intervention,
    create_intervention,
    engine as db_engine,
    get_db,
    get_intervention,
    list_interventions,
)
from app.demo_data import get_demo_dataset
from app.engine import IntelligenceEngine, intervention_baseline
from app.schemas import (
    AttendanceForecast,
    DataValidationRequest,
    DataValidationResponse,
    InterventionCreate,
    InterventionEvaluationRequest,
    InterventionOut,
    Insight,
)

Base.metadata.create_all(bind=db_engine)
intelligence = IntelligenceEngine()

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Explainable institutional analytics prototype. All bundled programme data are synthetic; "
        "this is not an official Swahilipot system."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.cors_origins),
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


@app.get("/", tags=["system"])
def root():
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "status": "running",
        "data_mode": "synthetic_demo_only",
        "docs": "/docs",
    }


@app.get("/api/v1/health", tags=["system"])
def health():
    return {"status": "healthy", "version": settings.app_version}


@app.get("/api/v1/demo/dataset", tags=["demo"])
def demo_dataset():
    """Return the explicitly labelled synthetic dataset used by this prototype."""
    return get_demo_dataset()


@app.get("/api/v1/demo/overview", tags=["demo"])
def demo_overview():
    return intelligence.overview()


@app.get("/api/v1/insights", response_model=list[Insight], tags=["intelligence"])
def get_insights():
    return intelligence.insights()


@app.get(
    "/api/v1/forecast/{cohort_id}",
    response_model=AttendanceForecast,
    tags=["intelligence"],
)
def get_attendance_forecast(
    cohort_id: str,
    horizon: Annotated[int, Query(ge=1, le=12)] = 4,
):
    known = {cohort["cohort_id"] for cohort in intelligence.dataset["cohorts"]}
    if cohort_id not in known:
        raise HTTPException(status_code=404, detail="Unknown cohort_id")
    return intelligence.forecast_attendance(cohort_id, horizon)


@app.post("/api/v1/data/validate", response_model=DataValidationResponse, tags=["data"])
def validate_data(request: DataValidationRequest):
    return intelligence.validate_attendance_records(request.records)


@app.get("/api/v1/interventions", response_model=list[InterventionOut], tags=["interventions"])
def get_interventions(db: Session = Depends(get_db)):
    return list_interventions(db)


@app.post(
    "/api/v1/interventions",
    response_model=InterventionOut,
    status_code=status.HTTP_201_CREATED,
    tags=["interventions"],
)
def post_intervention(request: InterventionCreate, db: Session = Depends(get_db)):
    known = {cohort["cohort_id"] for cohort in intelligence.dataset["cohorts"]}
    if request.cohort_id not in known:
        raise HTTPException(status_code=404, detail="Unknown cohort_id")
    try:
        baseline_rate, baseline_count = intervention_baseline(intelligence, request.cohort_id)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    item = create_intervention(
        db,
        **request.model_dump(),
        status="proposed",
        baseline_attendance_rate=baseline_rate,
        baseline_session_count=baseline_count,
    )
    return item


@app.post(
    "/api/v1/interventions/{intervention_id}/implement",
    response_model=InterventionOut,
    tags=["interventions"],
)
def implement_intervention(intervention_id: str, db: Session = Depends(get_db)):
    item = get_intervention(db, intervention_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Intervention not found")
    if item.status != "proposed":
        raise HTTPException(status_code=409, detail="Only proposed interventions can be marked implemented")
    item.status = "active"
    item.implemented_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(item)
    return item


@app.post(
    "/api/v1/interventions/{intervention_id}/evaluate",
    response_model=InterventionOut,
    tags=["interventions"],
)
def evaluate_intervention(
    intervention_id: str,
    request: InterventionEvaluationRequest,
    db: Session = Depends(get_db),
):
    item = get_intervention(db, intervention_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Intervention not found")
    if item.status != "active":
        raise HTTPException(status_code=409, detail="Intervention must be active before evaluation")

    follow_up_rate = sum(request.follow_up_attendance_counts) / (
        len(request.follow_up_attendance_counts) * request.enrolled_count
    )
    change_pp = (follow_up_rate - item.baseline_attendance_rate) * 100
    item.follow_up_attendance_rate = follow_up_rate
    item.change_percentage_points = change_pp
    item.status = "evaluated"
    item.evidence_references = json.dumps(request.evidence_references)
    direction = "increased" if change_pp > 0 else "decreased" if change_pp < 0 else "did not change"
    item.evaluation_note = (
        f"Follow-up attendance {direction} by {abs(change_pp):.2f} percentage points "
        "compared with the recorded baseline. This descriptive comparison does not establish "
        "that the intervention caused the change; context and an appropriate evaluation design are required."
    )
    db.commit()
    db.refresh(item)
    return item
