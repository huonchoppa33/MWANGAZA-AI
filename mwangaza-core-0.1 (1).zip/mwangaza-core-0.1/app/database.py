from __future__ import annotations

from datetime import date, datetime, timezone
from uuid import uuid4

from sqlalchemy import Date, DateTime, Float, Integer, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from app.config import settings

connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


class Intervention(Base):
    __tablename__ = "interventions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    title: Mapped[str] = mapped_column(String(180), nullable=False)
    cohort_id: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    management_question: Mapped[str] = mapped_column(Text, nullable=False)
    hypothesis: Mapped[str] = mapped_column(Text, nullable=False)
    planned_action: Mapped[str] = mapped_column(Text, nullable=False)
    owner_role: Mapped[str] = mapped_column(String(100), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="proposed")
    baseline_attendance_rate: Mapped[float] = mapped_column(Float, nullable=False)
    baseline_session_count: Mapped[int] = mapped_column(Integer, nullable=False)
    review_date: Mapped[date] = mapped_column(Date, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    implemented_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    follow_up_attendance_rate: Mapped[float | None] = mapped_column(Float, nullable=True)
    change_percentage_points: Mapped[float | None] = mapped_column(Float, nullable=True)
    evaluation_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    evidence_references: Mapped[str | None] = mapped_column(Text, nullable=True)


Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_intervention(db: Session, **kwargs) -> Intervention:
    item = Intervention(**kwargs)
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def get_intervention(db: Session, intervention_id: str) -> Intervention | None:
    return db.get(Intervention, intervention_id)


def list_interventions(db: Session) -> list[Intervention]:
    return list(db.scalars(select(Intervention).order_by(Intervention.created_at.desc())).all())
