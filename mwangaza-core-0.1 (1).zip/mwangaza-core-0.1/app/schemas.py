from __future__ import annotations

from datetime import date, datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class AttendanceSession(BaseModel):
    model_config = ConfigDict(extra="forbid")

    event_id: str = Field(min_length=1, max_length=80)
    cohort_id: str = Field(min_length=1, max_length=80)
    session_date: date
    enrolled_count: int = Field(gt=0)
    attendance_count: int = Field(ge=0)
    source_id: str = Field(min_length=1, max_length=100)

    @field_validator("attendance_count")
    @classmethod
    def attendance_cannot_exceed_enrolment(cls, value: int, info):
        enrolled = info.data.get("enrolled_count")
        if enrolled is not None and value > enrolled:
            raise ValueError("attendance_count cannot exceed enrolled_count")
        return value


class DataValidationRequest(BaseModel):
    records: list[dict[str, Any]] = Field(min_length=1, max_length=5000)


class DataValidationResponse(BaseModel):
    accepted_count: int
    rejected_count: int
    duplicate_event_ids: list[str]
    accepted_records: list[AttendanceSession]
    errors: list[dict[str, str | int]]
    note: str = "Validation only; this endpoint does not persist uploaded records."


class EvidenceItem(BaseModel):
    source_id: str
    description: str


class Insight(BaseModel):
    demo_only: bool = True
    insight_id: str
    category: Literal["attendance", "capacity", "data_quality", "programme"]
    severity: Literal["info", "watch", "high"]
    title: str
    finding: str
    recommendation: str
    confidence: Literal["high", "medium", "low"]
    evidence: list[EvidenceItem]
    limitations: list[str]
    human_review_required: bool = True


class ForecastPoint(BaseModel):
    period: int
    predicted_attendance_rate: float = Field(ge=0, le=1)


class AttendanceForecast(BaseModel):
    cohort_id: str
    method: str
    historical_sessions_used: int
    forecast: list[ForecastPoint]
    limitations: list[str]
    status: Literal["experimental", "insufficient_data"]


class InterventionCreate(BaseModel):
    title: str = Field(min_length=5, max_length=180)
    cohort_id: str = Field(min_length=1, max_length=80)
    management_question: str = Field(min_length=10, max_length=1000)
    hypothesis: str = Field(min_length=10, max_length=1000)
    planned_action: str = Field(min_length=10, max_length=2000)
    owner_role: str = Field(min_length=2, max_length=100)
    review_date: date


class InterventionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    title: str
    cohort_id: str
    management_question: str
    hypothesis: str
    planned_action: str
    owner_role: str
    status: str
    baseline_attendance_rate: float
    baseline_session_count: int
    review_date: date
    created_at: datetime
    implemented_at: datetime | None = None
    follow_up_attendance_rate: float | None = None
    change_percentage_points: float | None = None
    evaluation_note: str | None = None


class InterventionEvaluationRequest(BaseModel):
    follow_up_attendance_counts: list[int] = Field(min_length=1, max_length=30)
    enrolled_count: int = Field(gt=0)
    evidence_references: list[str] = Field(default_factory=list, max_length=30)

    @field_validator("follow_up_attendance_counts")
    @classmethod
    def counts_must_be_valid(cls, values: list[int], info):
        enrolled = info.data.get("enrolled_count")
        if any(value < 0 for value in values):
            raise ValueError("Attendance counts cannot be negative")
        if enrolled is not None and any(value > enrolled for value in values):
            raise ValueError("Attendance count cannot exceed enrolled_count")
        return values
