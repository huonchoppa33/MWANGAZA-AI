from datetime import date, timedelta


def test_health_and_demo_are_explicitly_labelled(client):
    health = client.get("/api/v1/health")
    assert health.status_code == 200
    assert health.json()["status"] == "healthy"

    overview = client.get("/api/v1/demo/overview")
    assert overview.status_code == 200
    assert overview.json()["demo_only"] is True
    assert "not Swahilipot" in overview.json()["dataset_notice"]


def test_insights_detect_synthetic_attendance_pattern(client):
    response = client.get("/api/v1/insights")
    assert response.status_code == 200
    insights = response.json()
    assert any("COH-TECH-A" in item["insight_id"] for item in insights)
    assert all(item["human_review_required"] for item in insights)


def test_forecast_is_experimental_and_has_limitations(client):
    response = client.get("/api/v1/forecast/COH-TECH-A?horizon=3")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "experimental"
    assert len(body["forecast"]) == 3
    assert body["limitations"]


def test_unknown_cohort_returns_404(client):
    assert client.get("/api/v1/forecast/not-a-cohort").status_code == 404


def test_data_validation_reports_duplicates_and_invalid_counts(client):
    payload = {
        "records": [
            {"event_id": "E1", "cohort_id": "C1", "session_date": "2026-10-01", "attendance_count": 8, "enrolled_count": 10, "source_id": "TEST"},
            {"event_id": "E1", "cohort_id": "C1", "session_date": "2026-10-08", "attendance_count": 8, "enrolled_count": 10, "source_id": "TEST"},
            {"event_id": "E2", "cohort_id": "C1", "session_date": "2026-10-15", "attendance_count": 12, "enrolled_count": 10, "source_id": "TEST"},
        ]
    }
    response = client.post("/api/v1/data/validate", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["accepted_count"] == 1
    assert body["rejected_count"] == 2
    assert body["duplicate_event_ids"] == ["E1"]
    assert body["note"].startswith("Validation only")


def test_intervention_lifecycle_preserves_non_causal_warning(client):
    create_payload = {
        "title": "Review technology cohort session timing",
        "cohort_id": "COH-TECH-A",
        "management_question": "Could session timing contribute to lower recent attendance?",
        "hypothesis": "A revised session time may improve attendance if scheduling is a key barrier.",
        "planned_action": "Run a manager-approved timetable adjustment for the next three sessions.",
        "owner_role": "Programme Manager",
        "review_date": str(date.today() + timedelta(days=30)),
    }
    created = client.post("/api/v1/interventions", json=create_payload)
    assert created.status_code == 201
    item = created.json()
    assert item["status"] == "proposed"
    assert item["baseline_session_count"] == 3

    implemented = client.post(f"/api/v1/interventions/{item['id']}/implement")
    assert implemented.status_code == 200
    assert implemented.json()["status"] == "active"

    evaluated = client.post(
        f"/api/v1/interventions/{item['id']}/evaluate",
        json={"follow_up_attendance_counts": [25, 26, 27], "enrolled_count": 32, "evidence_references": ["TEST-REPORT-01"]},
    )
    assert evaluated.status_code == 200
    result = evaluated.json()
    assert result["status"] == "evaluated"
    assert result["follow_up_attendance_rate"] > 0
    assert "does not establish" in result["evaluation_note"]
