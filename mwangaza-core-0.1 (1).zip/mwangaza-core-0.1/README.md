# MWANGAZA Core 0.1

**Institutional Intelligence Engine — backend prototype**

> IMPORTANT: The bundled dataset is synthetic demonstration data. This is an independent prototype, not an official Swahilipot product and not connected to Swahilipot systems or records.

## What works in 0.1

- Synthetic institutional overview and cohort summaries.
- Explainable insights for low recent attendance, declining attendance trends and high resource allocation.
- Experimental attendance projection using a simple linear trend baseline.
- Attendance record validation, including duplicate IDs and invalid counts.
- Intervention lifecycle: proposed → active → evaluated.
- Evidence references and explicit non-causal interpretation of before/after changes.
- OpenAPI documentation and automated tests.

## 1. Requirements

- Python 3.11 or newer recommended.
- pip.

## 2. Create a virtual environment

### Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt:

```bat
.venv\Scripts\activate.bat
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Run the API

From the project root:

```bash
uvicorn app.main:app --reload
```

Open:

- API docs: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/api/v1/health
- Synthetic overview: http://127.0.0.1:8000/api/v1/demo/overview
- Insights: http://127.0.0.1:8000/api/v1/insights

## 4. Run automated tests

```bash
pytest -q
```

## 5. Key endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/health` | Health check |
| GET | `/api/v1/demo/dataset` | Synthetic dataset, explicitly labelled |
| GET | `/api/v1/demo/overview` | Institutional demo summary |
| GET | `/api/v1/insights` | Evidence-backed demo insights |
| GET | `/api/v1/forecast/{cohort_id}?horizon=4` | Experimental attendance projection |
| POST | `/api/v1/data/validate` | Validate attendance records without saving |
| GET | `/api/v1/interventions` | List intervention records |
| POST | `/api/v1/interventions` | Create a proposed intervention |
| POST | `/api/v1/interventions/{id}/implement` | Mark a proposed intervention active |
| POST | `/api/v1/interventions/{id}/evaluate` | Record follow-up observations |

## 6. Example: create an intervention

```json
{
  "title": "Review technology cohort session timing",
  "cohort_id": "COH-TECH-A",
  "management_question": "Could session timing contribute to lower recent attendance?",
  "hypothesis": "A revised session time may improve attendance if scheduling is a key barrier.",
  "planned_action": "Run a manager-approved timetable adjustment for the next three sessions.",
  "owner_role": "Programme Manager",
  "review_date": "2026-12-15"
}
```

Then call the returned intervention ID at:

```text
POST /api/v1/interventions/{id}/implement
```

And evaluate with:

```json
{
  "follow_up_attendance_counts": [25, 26, 27],
  "enrolled_count": 32,
  "evidence_references": ["FOLLOW-UP-REPORT-001"]
}
```

The evaluation records a descriptive before/after change. It does not establish that the intervention caused the change.

## Current limitations

- No real Swahilipot data, accounts, APIs or systems are connected.
- No LLM or autonomous agent is enabled.
- Forecasts use synthetic cohort-level data and are experimental.
- Insights are explainable rules and statistical trend checks, not a trained foundation model.
- The prototype is not production-ready; authentication, authorisation, managed secrets, formal audit controls, backups, monitoring, DPIA and deployment hardening remain required.

See `docs/ARCHITECTURE.md` and `docs/DATA_MODEL.md`.
