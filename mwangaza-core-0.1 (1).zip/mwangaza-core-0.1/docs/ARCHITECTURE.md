# MWANGAZA Core 0.1 — Architecture

## Purpose

This is the first executable backend slice of MWANGAZA. It demonstrates an explainable institutional intelligence workflow using synthetic data. It is not an official Swahilipot system and it is not connected to Swahilipot databases.

## Components

- **FastAPI API:** health, demonstration overview, insights, forecast, data validation and intervention endpoints.
- **Intelligence engine:** deterministic, explainable checks for low recent attendance, declining attendance trends and high resource allocation.
- **Forecast baseline:** ordinary least-squares linear trend projection. This is experimental, not a validated ML model.
- **Intervention register:** SQLite by default; can use PostgreSQL through `DATABASE_URL`. Records proposed, active and evaluated interventions.
- **Synthetic dataset:** three illustrative programmes, three cohorts, ten attendance sessions per cohort and sample resource allocations.

## Evidence and safety rules

1. All built-in records are synthetic and visibly labelled as such.
2. Insights contain supporting event/resource identifiers and limitations.
3. Recommendations require human review.
4. Forecasts are explicitly marked experimental.
5. Before/after intervention changes are descriptive and are not labelled causal effects.
6. Data validation does not persist imported records.
7. No participant-level eligibility, risk scoring or automated decisions are implemented.

## Production evolution

Before real-data integration, complete institutional discovery, approve indicator definitions, establish a lawful processing basis, complete a DPIA where required, define data retention/access policies and obtain written approval for each source integration. Replace local SQLite with a managed PostgreSQL deployment only after reviewing security, backup, residency and operational requirements.
