# MWANGAZA Core 0.1 — Data model

## Current prototype entities

### Programme
- `programme_id`
- `name`
- `department`

### Cohort
- `cohort_id`
- `programme_id`
- `name`
- `enrolled_count`
- `capacity`

### Attendance session event
- `event_id`
- `cohort_id`
- `session_date`
- `attendance_count`
- `enrolled_count`
- `source_id`

### Resource allocation
- `resource_id`
- `resource_type`
- `capacity`
- `allocated`
- `programme_id`

### Intervention
- `id`
- `title`
- `cohort_id`
- `management_question`
- `hypothesis`
- `planned_action`
- `owner_role`
- `status`
- `baseline_attendance_rate`
- `baseline_session_count`
- `review_date`
- `created_at`
- `implemented_at`
- `follow_up_attendance_rate`
- `change_percentage_points`
- `evaluation_note`
- `evidence_references`

## Important limitations

- The initial model is intentionally small and cohort-level.
- It contains no personal or participant-identifying records.
- A production institutional model needs approved data definitions and a source-of-truth inventory.
- All identifiers in the demo dataset are artificial.
