# Next engineering steps after Core 0.1

## Core 0.2 — production-shaped data foundations

- Move the institutional dataset into explicit database tables and migrations.
- Add tenant/institution boundary and department/role permissions.
- Add a staging area for uploads, preview, approval and idempotent ingestion.
- Add source registry, data contracts, provenance and indicator versioning.
- Replace direct demo dataset access with repository interfaces.

## Core 0.3 — document intelligence

- Add approved document upload and extraction.
- Add permission-aware retrieval and citation references.
- Add an LLM provider adapter behind a server-side interface.
- Require evidence citations and abstention when evidence is missing.
- Do not send personal records or confidential source documents to an external model without explicit approval and a data-processing review.

## Core 0.4 — validated analytical models

- Obtain permission for a representative, minimised historical dataset.
- Define forecast targets and time windows with programme owners.
- Establish naïve statistical baselines.
- Use time-based holdouts and backtesting.
- Add ML only where it beats baselines and remains calibrated.
- Assess fairness and subgroup performance where lawful and statistically meaningful.

## Production pilot gate

A real-data pilot requires institutional approval, a source inventory, lawful basis, privacy review and DPIA where required, approved indicator definitions, access control, audit logging, backup/recovery and security testing.
